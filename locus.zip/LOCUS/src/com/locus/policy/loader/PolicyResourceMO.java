package com.locus.policy.loader;

public class PolicyResourceMO {
	 /*
	{
	"policy":[
		{"admin":{"resources":
		[{"resourceName":"resource1","read":true,"write":true,"delete":true},
		{"resourceName":"resource2","read":true,"write":true,"delete":true},
		{"resourceName":"resource3, "read":true,"write":true,"delete":true"}]
		}},
		
		{"monitor":{"resources":
		[{"resource1,"read":true,"write":false,"delete":false"},
		 {"resource2","read":true,"write":false,"delete":false}]
		}},
		{"external":{{"resources":[{"resource1","read":true,"write":true,"delete":false}])
		}}
	}
	*/	
	private String resourceName;
	private boolean read;
	private boolean write;
	private boolean delete;
	public String getResourceName() {
		return resourceName;
	}
	public void setResourceName(String resourceName) {
		this.resourceName = resourceName;
	}
	public boolean isRead() {
		return read;
	}
	public void setRead(boolean read) {
		this.read = read;
	}
	public boolean isWrite() {
		return write;
	}
	public void setWrite(boolean write) {
		this.write = write;
	}
	public boolean isDelete() {
		return delete;
	}
	public void setDelete(boolean delete) {
		this.delete = delete;
	}
	

}
