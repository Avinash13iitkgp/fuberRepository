package com.locus.policy.loader;

import java.util.List;

public class RolesMO {
	/*
	 * /*
{
"policy":[
	{"admin":{"resources":
	[{"resourceName":"resource1","read":true,"write":true,"delete":true},
	{"resourceName":"resource2","read":true,"write":true,"delete":true},
	{"resourceName":"resource3, "read":true,"write":true,"delete":true"}]
	}},
	
	{"monitor":{"resources":
	[{"resource1,"read":true,"write":false,"delete":false"},
	 {"resource2","read":true,"write":false,"delete":false}]
	}},
	{"external":{{"resources":[{"resource1","read":true,"write":true,"delete":false}])
	}}
}
*/
	private List<PolicyResourceMO> resources;

	public List<PolicyResourceMO> getResources() {
		return resources;
	}

	public void setResources(List<PolicyResourceMO> resources) {
		this.resources = resources;
	}
	
	
}


/*
{
"policy":[
	{"admin":{"read":true,"write":true,"delete":true,
		"resources":["resource1","resource2","resource3"]
	}},
	{"monitor":{"read":true,"write":false,"delete":false,
		"resources":["resource1","resource2"]
	}},
	{"exterbal":{"read":true,"write":true,"delete":false,
		"resources":["resource1"]
	}},	
	{"customer":{"read":true,"write":false,"delete":false,
		"resources":["resource1","resource2"]
	}}]
}*/