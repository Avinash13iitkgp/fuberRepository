package com.locus.policy.loader;

import java.util.List;
import java.util.Map;

public class PolicyMO {
	List<Map<String,RolesMO>> policy;

	public List<Map<String,RolesMO>> getPolicy() {
		return policy;
	}

	public void setPolicy(List<Map<String,RolesMO>> policy) {
		this.policy = policy;
	}

	@Override
	public String toString() {
		return "PolicyMO [policy=" + policy + "]";
	}

	
	
	
}
/*
{
"policy":[
	{"admin":{"resources":
	[{"resourceName":"resource1","read":true,"write":true,"delete":true},
	{"resourceName":"resource2","read":true,"write":true,"delete":true},
	{"resourceName":"resource3, "read":true,"write":true,"delete":true"}]
	}},
	
	{"monitor":{"resources":
	[{"resourceName":"resource1,"read":true,"write":false,"delete":false"},
	 {"resourceName":"resource2","read":true,"write":false,"delete":false}]
	}},
	{"external":{{"resourceName":"resources":[{"resource1","read":true,"write":true,"delete":false}])
	}}
}
*/