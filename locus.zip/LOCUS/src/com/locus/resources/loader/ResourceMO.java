package com.locus.resources.loader;

import java.util.List;

public class ResourceMO {
	/*
	 * {
	"resources":[
		{"name":"resource1","folders":["resources/folder1/","resources/folder2/","resources/file1.txt"]},
	
		{"name":"resource2","folders":["resources/folder2/"]},
		{"name":"resouce3","folders":["resources/folder3/"]}		
	]
}
	 */
	    private List<Resources> resources;

	    
	    public List<Resources> getResources ()
	    {
	        return resources;
	    }

	    public void setResources (List<Resources> resources)
	    {
	        this.resources = resources;
	    }

	   
				
	
}
