package com.locus.auth.main;
import java.util.ArrayList;
import java.util.List;

import com.locus.auth.AuthorizationHandler;
import com.locus.auth.impl.LocusAuthorizationHandlerImpl;
import com.locus.auth.impl.RoleEnum;
import com.locus.auth.users.User;
import com.locus.auth.users.impl.LocusUserImpl;
import com.locus.auth.users.impl.PrivilegesEnum;
class UserRoleAuthenticationMain {

	public static void main(String[] args) {
		List<User>users=new ArrayList<User>();		
		
		User user1=new LocusUserImpl();
		user1.setName("Avinash");
		users.add(user1);
		
		AuthorizationHandler authorizationHandler=new LocusAuthorizationHandlerImpl();
		authorizationHandler.grantRole(user1, RoleEnum.ADMIN.getRole());
		
		
		
		System.out.println(authorizationHandler.checkPrivilegesOfUser(user1,"resources/folder1",PrivilegesEnum.READ.getPrivilege()));
		//authorizationHandler.revokeRole(user1, RoleEnum.ADMIN.getRole());
		authorizationHandler.revokeAllRoles(user1);
		System.out.println(authorizationHandler.checkPrivilegesOfUser(user1,"resources/folder1",PrivilegesEnum.READ.getPrivilege()));
		
		authorizationHandler.grantRole(user1, RoleEnum.EXTERNAL.getRole());
		
		System.out.println(authorizationHandler.checkPrivilegesOfUser(user1,"resources/folder1",PrivilegesEnum.READ.getPrivilege()));
		authorizationHandler.grantRole(user1, RoleEnum.MONITOR.getRole());
		authorizationHandler.grantRole(user1, RoleEnum.EXTERNAL.getRole());
		
		System.out.println(authorizationHandler.checkPrivilegesOfUser(user1,"resources/folder1",PrivilegesEnum.READ.getPrivilege()));
		
	}

}
