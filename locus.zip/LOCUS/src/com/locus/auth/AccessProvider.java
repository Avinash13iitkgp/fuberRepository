package com.locus.auth;

import com.locus.auth.users.User;

public interface AccessProvider {
	boolean revokeRole(User user,String role);
	boolean grantRole(User user, String role);
}
