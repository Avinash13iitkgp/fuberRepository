package com.locus.auth.impl;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import com.locus.auth.AccessProvider;
import com.locus.auth.users.Role;
import com.locus.auth.users.User;
import com.locus.auth.users.impl.LocusRoleImpl;

public class LocusAccessProviderImpl implements AccessProvider {

	@Override
	public boolean revokeRole(User user, String role) {
		if(user==null || user.getRoles()==null || user.getRoles().size()==0){
			return false;
		}
		if(role==null || "".equalsIgnoreCase(role)){
			return false;
		}
		Set<Role> roles = user.getRoles();
		Iterator<Role> it = roles.iterator();
		while(it.hasNext()){
			Role roleEach = it.next();
			if(roleEach.getRoleName()!=null && role.equalsIgnoreCase(roleEach.getRoleName())){
				it.remove();
				return true;
			}
		}
		return false;
		
	}

	@Override
	public boolean grantRole(User user, String role) {
		if(user==null)
		{
			return false;
		}
		if(user.getRoles()==null){
			Set<Role> roles=new HashSet<Role>();
			user.setRoles(roles);		
		}
		user.getRoles().add(getRoleFromRoleEnum(role));
		return true;
	}

	private Role getRoleFromRoleEnum(String role) {
		LocusRoleImpl role1=null;
		if(RoleEnum.ADMIN.getRole().equals(role))
			{
				role1=new LocusRoleImpl();
				role1.setRoleName(role);
			}
		if(RoleEnum.EXTERNAL.getRole().equals(role)){
			role1=new LocusRoleImpl();
			role1.setRoleName(role);
		}
		if(RoleEnum.MONITOR.getRole().equals(role)){
			role1=new LocusRoleImpl();
			role1.setRoleName(role);
		}
		return role1;
	}
	
}
