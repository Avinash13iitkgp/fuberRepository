package com.locus.auth.impl;

public enum RoleEnum {
	ADMIN("admin"),MONITOR("monitor"),EXTERNAL("external");
	private String role;
	RoleEnum(String role) {
		this.role=role;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	
}
