package com.locus.auth.impl;

import com.locus.auth.AccessProvider;
import com.locus.auth.AuthenticationValidator;
import com.locus.auth.AuthorizationHandler;
import com.locus.auth.users.User;

public class LocusAuthorizationHandlerImpl implements AuthorizationHandler {

	private AccessProvider accessProvider;
	private AuthenticationValidator authenticationValidator;
	
	
	public LocusAuthorizationHandlerImpl() {
		this.accessProvider = new LocusAccessProviderImpl();
		this.authenticationValidator = new LocusAuthenticationValidatorImpl();
	}



	@Override
	public boolean checkPrivilegesOfUser(User user, String path, String privilege) {
		return authenticationValidator.checkPrivilegesOfUser(user, path, privilege);
	}



	@Override
	public boolean grantRole(User user,String role) {
		return accessProvider.grantRole(user,role);
	}



	@Override
	public boolean revokeRole(User user,String role) {
		return accessProvider.revokeRole(user, role);
	}



	@Override
	public boolean revokeAllRoles(User user) {
		if(user==null){
			return false;
		}
		user.setRoles(null);
		return true;
	}

}
