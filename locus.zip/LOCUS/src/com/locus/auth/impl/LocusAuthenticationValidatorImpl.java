package com.locus.auth.impl;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.locus.auth.AuthenticationValidator;
import com.locus.auth.users.Role;
import com.locus.auth.users.User;
import com.locus.auth.users.impl.PrivilegesEnum;
import com.locus.policy.loader.PolicyClassLoader;
import com.locus.policy.loader.PolicyMO;
import com.locus.policy.loader.PolicyResourceMO;
import com.locus.policy.loader.RolesMO;
import com.locus.resources.loader.ResourceClassLoader;
import com.locus.resources.loader.ResourceMO;
import com.locus.resources.loader.Resources;

public class LocusAuthenticationValidatorImpl implements AuthenticationValidator{
	
	ResourceMO resourceMO=ResourceClassLoader.getPolicyMO();
	PolicyMO policyMO=PolicyClassLoader.getPolicyMO();
	@Override
	public boolean checkPrivilegesOfUser(User user, String path, String privilege) {
		if(user==null){
			return false;
		}
		if(path==null || "".equalsIgnoreCase(path)){
			return false;
		}
		Set<Role>roles= user.getRoles();
		if(roles==null || roles.size()==0){  //no roles have been assigned to user, so no access at all
			return false;
		}
		Iterator<Role> it = roles.iterator();
		while(it.hasNext()){
			Role role = it.next();
			String roleName=role.getRoleName();
			if(policyMO.getPolicy()!=null && policyMO.getPolicy().size()>0){
				for(int i=0;i<policyMO.getPolicy().size();i++){
					Map<String, RolesMO> policy = policyMO.getPolicy().get(i);
					if(policy.containsKey(roleName)){
						RolesMO policySpecific = policy.get(roleName);
						if(policySpecific!=null){
							List<PolicyResourceMO> resouces = policySpecific.getResources();
							if(resouces!=null && resouces.size()>0){
								for(int i1=0;i1<resouces.size();i1++){
									boolean check=checkIfResourceHasAccessToPath(resouces.get(i1),path);  //checks if resource has the path we are trying to access
									if(check){
										if(validatePrivileges(privilege,resouces.get(i1))){
											return true;
										}									
									}
								}
							}
						}
					}
				}
			}
		}
		return false;
	}
	private boolean validatePrivileges(String privilege, PolicyResourceMO policyResourceMO) {
		if(PrivilegesEnum.WRITE.getPrivilege().equalsIgnoreCase(privilege)){
			if(policyResourceMO.isWrite()){
				return true;
			}
			return false;
		}
		if(PrivilegesEnum.READ.getPrivilege().equalsIgnoreCase(privilege)){
			if(policyResourceMO.isRead()){
				return true;
			}
			return false;
		}
		if(PrivilegesEnum.DELETE.getPrivilege().equalsIgnoreCase(privilege)){
			if(policyResourceMO.isDelete()){
				return true;
			}
			return false;
		}
		return false;
	}
	private boolean checkIfResourceHasAccessToPath(PolicyResourceMO policyResourceMO, String path) {
		if(resourceMO==null || resourceMO.getResources()==null || resourceMO.getResources().size()==0 || policyResourceMO==null ||policyResourceMO.getResourceName()==null || "".equals(policyResourceMO.getResourceName())){
			return false;
		}
		List<Resources> resources = resourceMO.getResources();
		for(int i=0;i<resources.size();i++){
			if(policyResourceMO.getResourceName().equals(resources.get(i).getName())){
				List<String> folders = resources.get(i).getFolders();
				List<String> files = resources.get(i).getFiles();	
				if(checkIfExist(folders,path,true) || checkIfExist(files, path,false)){
					return true;
				}else{
					return false;
				}				
			}			
		}
		return false;
		
	}
	private boolean checkIfExist(List<String> folders, String path, boolean isFolder) {
		if(folders==null || folders.size()==0 || path==null || "".contentEquals(path)){
			return false;
		}
		for(int i=0;i<folders.size();i++){
			if(isFolder){
				if(path.startsWith(folders.get(i))){
					return true;
				}
			}
			else if(folders.get(i).equalsIgnoreCase(path)){
				return true;
			}
		}
		return false;
	}

	
}
