package com.locus.auth;

import com.locus.auth.users.User;

public interface AuthorizationHandler {
	boolean checkPrivilegesOfUser(User user, String path, String privilege);
	boolean grantRole(User user, String role);
	boolean revokeRole(User user, String role);
	boolean revokeAllRoles(User user);
}
