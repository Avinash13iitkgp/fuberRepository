package com.locus.auth.users.impl;

public enum PrivilegesEnum {
	READ("read"),WRITE("write"),DELETE("delete");
	private String privilege;
	private PrivilegesEnum(String privilege) {
	this.privilege = privilege;
	}
	public String getPrivilege() {
		return privilege;
	}
	public void setPrivilege(String privilege) {
		this.privilege = privilege;
	}	
}
