package com.locus.auth.users.impl;

import com.locus.auth.users.Role;

public class LocusRoleImpl implements Role {

	private String roleName;
	
	@Override
	public String getRoleName() {
		return roleName;
	}

	@Override
	public void setRoleName(String roleName) {
		this.roleName=roleName;		
	}
	

}
