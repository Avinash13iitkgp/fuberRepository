package cabs.fuber.controller.rest.resources;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
@XmlRootElement(name="fuberCustomerRequest")
@XmlType(propOrder={"customerName","startLocation","endLocation","customerCabPreference","phone"})
public class FuberCustomerRequest {
	private String customerName=null;
	private GeoLocation startLocation=null;
	private GeoLocation endLocation=null;
	private String customerCabPreference=null;
	private String phone;
	
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public GeoLocation getStartLocation() {
		return startLocation;
	}
	public void setStartLocation(GeoLocation startLocation) {
		this.startLocation = startLocation;
	}
	public GeoLocation getEndLocation() {
		return endLocation;
	}
	public void setEndLocation(GeoLocation endLocation) {
		this.endLocation = endLocation;
	}
	public String getCustomerCabPreference() {
		return customerCabPreference;
	}
	public void setCustomerCabPreference(String customerCabPreference) {
		this.customerCabPreference = customerCabPreference;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	
}
