package cabs.fuber.controller.rest;

import java.io.IOException;
import java.util.Enumeration;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.xml.bind.JAXBException;

import cabs.fuber.controller.FuberEventHandler;
import cabs.fuber.controller.MOVOConvertor;
import cabs.fuber.controller.rest.resources.FuberCabsRequest;
import cabs.fuber.controller.rest.resources.FuberCabsResponse;
import cabs.fuber.controller.rest.resources.FuberCustomerRequest;
import cabs.fuber.controller.rest.resources.FuberCustomerResponse;
import cabs.fuber.model.GlobalConstants;
import cabs.fuber.view.enums.CustomerCabPreference;
import cabs.fuber.view.vo.CabStatusVO;
import cabs.fuber.view.vo.CabTypeVO;
import cabs.fuber.view.vo.FuberCabVO;
import cabs.fuber.view.vo.FuberCustomerVO;
import cabs.fuber.view.vo.GeoLocationVO;

@Path("/customers")
public class FuberRestAPIForCustomers {
	Logger logger=Logger.getLogger(GlobalConstants.LOG_REST_FILE_PATH);
	
	@GET
	@Consumes({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
	@Produces({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
	@Path("/")
	public Response getAvaiableCabs(){
		logger.info("getAvailableCabs method"); 
		FuberEventHandler fuberEventHandler=new FuberEventHandler();
		FuberCustomerResponse fuberCustomerResponse=new FuberCustomerResponse();
		try{
			List<FuberCabVO> cabs = fuberEventHandler.getListOfAvailableCabsVO();
			if(cabs!=null && cabs.size()>0){
				String cabsResponse="";
				for(int i=0;i<cabs.size();i++){
					cabsResponse=cabsResponse+"[Cab-Number:"+cabs.get(i).getCabNumber();
					cabsResponse=cabsResponse+",\t Cab-Name:"+cabs.get(i).getDriverName();
					cabsResponse=cabsResponse+",\t Cab-Type:"+cabs.get(i).getCabType();
					cabsResponse=cabsResponse+"] \n";
				}
				fuberCustomerResponse.setMessage(cabsResponse);
				return Response.status(200).entity(fuberCustomerResponse).build();
			}
			fuberCustomerResponse.setMessage("No cabs available");
		}catch(Exception e){
			fuberCustomerResponse.setMessage("Error in getting cab. ");
		}
		 return Response.status(200).entity(fuberCustomerResponse).build();
		
	}
	
	
	@PUT	
	@Produces({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
	@Consumes({MediaType.APPLICATION_XML,MediaType.APPLICATION_JSON})
	@Path("/")
	public Response getNearestCab(FuberCustomerRequest request){
		logger.info("In getNearestCab()");
		FuberCustomerResponse response=new FuberCustomerResponse();
		FuberEventHandler fuberEventHandler=new FuberEventHandler();
		FuberCustomerVO fuberCustomerVO=null;
		if(request!=null && request.getStartLocation()!=null){
			fuberCustomerVO=getFuberCustomerVOFromRequest(request);
		}else{
			response.setMessage("Enter Your Start Coordinates");
		}
		String  cabsResponse="";
		try{
			FuberCabVO nearestCab = fuberEventHandler.getNearestCab(fuberCustomerVO);
			if(nearestCab!=null){
				cabsResponse = "[Cab-Number:"+nearestCab.getCabNumber();
				cabsResponse=cabsResponse+",\t Cab-Name:"+nearestCab.getDriverName();
				cabsResponse=cabsResponse+",\t Cab-Type:"+nearestCab.getCabType();
				float lat1=nearestCab.getCabCoordinates().getLatitude();
				float lng1=nearestCab.getCabCoordinates().getLongitude();
				float lat2=fuberCustomerVO.getStartLocation().getLatitude();
				float lng2=fuberCustomerVO.getStartLocation().getLongitude();
				cabsResponse=cabsResponse+",\t Distance:"+fuberEventHandler.getDistanceBetweenTwoCoordinates(lat1, lng1, lat2, lng2);
				cabsResponse=cabsResponse+"]\n";
			}
			response.setMessage(cabsResponse);
		}catch(RuntimeException e){
			response.setMessage("Cannot find nearest Cab");
		}		
		return Response.status(201).entity(response).build();
	}
	
	
	@PUT
	@Produces({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
	@Consumes({MediaType.APPLICATION_XML,MediaType.APPLICATION_JSON})
	@Path("/assign")
	public Response assignCab(FuberCustomerRequest request){
		logger.info("In assignCab()");
		FuberCustomerResponse response=new FuberCustomerResponse();
		FuberEventHandler fuberEventHandler=new FuberEventHandler();
		FuberCustomerVO fuberCustomerVO=getFuberCustomerVOFromRequest(request);
		try{
			FuberCabVO nearestCab = fuberEventHandler.getNearestCab(fuberCustomerVO);
			if(nearestCab!=null){
				try {
					fuberEventHandler.assignCab(fuberCustomerVO, nearestCab);
					response.setMessage("Assigned Cab");
				} catch (IOException e) {
					response.setMessage("Error Assigning Cab");
				}
			}
		}catch(RuntimeException e){
			response.setMessage("Not Assigned");
		}		
		return Response.status(200).entity(response).build();
	}
	
	
	@PUT
	@Produces({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
	@Consumes({MediaType.APPLICATION_XML,MediaType.APPLICATION_JSON})
	@Path("/release")
	public Response releaseCab(FuberCustomerRequest request){
		logger.info("In releaseCab()");
		FuberCustomerResponse response=new FuberCustomerResponse();
		FuberEventHandler fuberEventHandler=new FuberEventHandler();
		FuberCustomerVO fuberCustomerVO=getFuberCustomerVOFromRequest(request);
		if(request==null){
			return null;
		}
		try {
			response.setMessage(fuberEventHandler.releaseCab(fuberCustomerVO));
		} catch (IOException e) {
				response.setMessage("Error in releasing cab");
				logger.log(Level.ALL, e.getMessage());
		}		
		return Response.status(201).entity(response).build();
	}
	
	@PUT
	@Produces({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
	@Consumes({MediaType.APPLICATION_XML,MediaType.APPLICATION_JSON})
	@Path("/update")
	public Response updateCustomerData(FuberCustomerRequest request){
		logger.info("In updateCustomerData");
		FuberCustomerResponse response=new FuberCustomerResponse();
		FuberEventHandler fuberEventHandler=new FuberEventHandler();
		FuberCustomerVO fuberCustomerVO=getFuberCustomerVOFromRequest(request);
		if(request==null){
			logger.log(Level.ALL, "request is null in updateCustomerData");
		}
		else{
			try {
				boolean val=fuberEventHandler.updateCustomerData(fuberCustomerVO, true);
			} catch (JAXBException | IOException e) {
				logger.log(Level.ALL, "Error in method updateCustomerData "+e.getLocalizedMessage());
			}
		}
		return Response.status(201).entity(response).build();
	}
	
	
	public FuberCustomerVO getFuberCustomerVOFromRequest(FuberCustomerRequest request){
			if(request==null){
				return null;
			}		
			FuberCustomerVO vo=new FuberCustomerVO();
			
			if(request.getCustomerCabPreference()!=null && "pink".equalsIgnoreCase(request.getCustomerCabPreference())){
				vo.setCustomerCabPreference(CustomerCabPreference.Pink);
			}else{
				vo.setCustomerCabPreference(CustomerCabPreference.Default);
			}
			vo.setCustomerName(request.getCustomerName());
			if(request.getEndLocation()!=null)
			{
				vo.setEndLocation(new GeoLocationVO(request.getEndLocation().getLatitude(),request.getEndLocation().getLongitude() ));
			}
			if(request.getStartLocation()!=null)
			{
				vo.setStartLocation(new GeoLocationVO(request.getStartLocation().getLatitude(),request.getStartLocation().getLongitude() ));
			}
			vo.setPhone(request.getPhone());
			return vo;
	}
}
