package cabs.fuber.controller;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.xml.bind.JAXBException;

import cabs.fuber.model.GlobalConstants;
import cabs.fuber.model.data.mo.CabStatusMO;
import cabs.fuber.model.data.mo.CabTypeMO;
import cabs.fuber.model.data.mo.FuberCabsMO;
import cabs.fuber.model.data.mo.FuberCustomerMOs;
import cabs.fuber.model.data.mo.FuberEachCabMO;
import cabs.fuber.model.data.mo.FuberEachCustomerMO;
import cabs.fuber.model.datastores.impl.FileDataSourceImpl;
import cabs.fuber.view.vo.CabStatusVO;
import cabs.fuber.view.vo.FuberCabVO;
import cabs.fuber.view.vo.FuberCustomerVO;
import cabs.fuber.view.vo.GeoLocationVO;
import cabs.fuber.view.enums.CustomerCabPreference;

public class FuberEventHandler {

	private static final int POOL_SIZE =100;
	CabCustomerInitializer cabCustomerInitializer=new CabCustomerInitializer();
	private ExecutorService executorService=Executors.newFixedThreadPool(POOL_SIZE);
	private long startTime;
	private long endTime;
	public FuberCabVO getNearestCab(FuberCustomerVO fuberCustomerVO)throws RuntimeException{
		if(fuberCustomerVO==null){
			return null;
		}
		if(fuberCustomerVO.getStartLocation() == null){
			throw new RuntimeException("start location for customer is not updated");
		}
		FuberCabVO nearestCabVO=null;
		
		GeoLocationVO custLocationVO=fuberCustomerVO.getStartLocation();
		
		if(cabCustomerInitializer.fuberCabMO!=null){
			List<FuberEachCabMO> cabsMO = cabCustomerInitializer.fuberCabMO.getCabs();
			if(cabsMO==null || cabsMO.size()==0){
				return null;
			}
			float MIN_DISTANCE=999999999.9f;

			for(int i=0;i<cabsMO.size();i++){
				if(cabsMO.get(i).getStatus().equals(CabStatusMO.Active) && checkCustomerPreferenceAndCabType(fuberCustomerVO.getCustomerCabPreference(),cabsMO.get(i).getCabType())){
				float distance=getDistanceBetweenTwoCoordinates(cabsMO.get(i).getCabCoordinates().getLatitude(),cabsMO.get(i).getCabCoordinates().getLongitude(),custLocationVO.getLatitude(),custLocationVO.getLongitude());
				if(distance<MIN_DISTANCE){
					MIN_DISTANCE=distance;
					nearestCabVO=MOVOConvertor.getVOFromMO(cabsMO.get(i));
					}
				}
			}
			}
		
		if(nearestCabVO!=null){
			final FuberCabVO nearCabVOFinal=nearestCabVO;
			executorService.execute(new Runnable() {
				
				@Override
				public void run() {
					updateJourneyStart(nearCabVOFinal);					
				}
			});
			}
		executorService.shutdown();
		return nearestCabVO;
	}
	public void removeAllCabs() throws JAXBException, IOException{
		FuberCabsMO mo=new FuberCabsMO();
		addCabs(mo,false);
	}
	public List<FuberCabVO> getListOfAvailableCabsVO() throws JAXBException{
		List<FuberCabVO> cabs=new ArrayList<FuberCabVO>();
		FuberCabsMO cabsExisting = FuberUtils.getInstance().getFuberCabMOFromDataStore();
		if(cabsExisting!=null && cabsExisting.getCabs()!=null && cabsExisting.getCabs().size()>0){
			for(int i=0;i<cabsExisting.getCabs().size();i++){
				if(cabsExisting.getCabs().get(i).getStatus()!=null && cabsExisting.getCabs().get(i).getStatus().equals(CabStatusMO.Active)){
					FuberCabVO cab=new FuberCabVO();
					cab=MOVOConvertor.getVOFromMO(cabsExisting.getCabs().get(i));	
					cabs.add(cab);
				}				
			}			
		}
		return cabs;
	}
	public List<FuberCustomerVO> getListOfAvailableCustoemerVO() throws JAXBException{
		List<FuberCustomerVO> customers=new ArrayList<FuberCustomerVO>();
		FuberCustomerMOs customersExisting = FuberUtils.getInstance().getFuberCustomerMOFromDataStore();
		if(customersExisting!=null && customersExisting.getFuberEachCustomerMO()!=null && customersExisting.getFuberEachCustomerMO().size()>0){
			for(int i=0;i<customersExisting.getFuberEachCustomerMO().size();i++){
				FuberCustomerVO customer=new FuberCustomerVO();
				customer=MOVOConvertor.getVOFromMO(customersExisting.getFuberEachCustomerMO().get(i));	
				customers.add(customer);
			}			
		}
		return customers;
	}
	private boolean checkCustomerPreferenceAndCabType(CustomerCabPreference customerCabPreference, CabTypeMO cabType) {
		if(CustomerCabPreference.Pink.equals(customerCabPreference)){
			if(CabTypeMO.Pink.equals(cabType)){
				return true;
			}
			return false;
		}
		return true;
	}
	
	public float getDistanceBetweenTwoCoordinates(float lat1, float lng1,float lat2,float lng2) {
		 double earthRadius = 6371000; //meters
		    double dLat = Math.toRadians(lat2-lat1);
		    double dLng = Math.toRadians(lng2-lng1);
		    double a = Math.sin(dLat/2) * Math.sin(dLat/2) +
		               Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2)) *
		               Math.sin(dLng/2) * Math.sin(dLng/2);
		    double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
		    float dist = (float) (earthRadius * c);
		    return dist;
	}
	public void updateJourneyEnd(){
		//TODO end of journey update the list of cabs with the current location of cab
	}
	public void updateJourneyStart(FuberCabVO nearCabVOFinal){
		
		
	}
	public void addCab(FuberCabVO vo,boolean append) throws JAXBException, IOException{
		MOVOConvertor movoConvertor=new MOVOConvertor();
		FuberEachCabMO mo = movoConvertor.getMOFromVO(vo);
		addCab(mo, append);
		
	}
	private boolean checkUniquenessOfCab(List<FuberEachCabMO> cabs, FuberEachCabMO mo)throws IOException {
		if(cabs==null || mo==null || cabs.size()==0){
			return false;
		}
		if(mo.getCabNumber()==null || "".contentEquals(mo.getCabNumber().trim())){
			return false;
		}
		for(int i=0;i<cabs.size();i++){
			if(cabs.get(i).getCabNumber()!=null && cabs.get(i).getCabNumber().equalsIgnoreCase(mo.getCabNumber())){
				throw new IOException("Cab Already In Queue. Only one entry is allowed");
			}
		}
		return true;
	}
	public void addCustomer(FuberEachCustomerMO mo,boolean append) throws JAXBException, IOException{
		File file=null;
		if(FuberUtils.getInstance().getDataSource()!=null && FuberUtils.getInstance().getDataSource() instanceof FileDataSourceImpl){
			 file=((FileDataSourceImpl)FuberUtils.getInstance().getDataSource()).getCustomerDataFile();
		}
		if(!append){
			FuberCustomerMOs mos=new FuberCustomerMOs();
			mos.getFuberEachCustomerMO().add(mo);
			JAXBXMLParsers.writeXMLDataToFileCustomerMO(file, mos);
		}else{
			FuberCustomerMOs customerExisting = FuberUtils.getInstance().getFuberCustomerMOFromDataStore();
			if(customerExisting!=null && customerExisting.getFuberEachCustomerMO()!=null && customerExisting.getFuberEachCustomerMO().size()>0 && checkUniquenessOfCustomer(customerExisting.getFuberEachCustomerMO(),mo)){
				customerExisting.getFuberEachCustomerMO().add(mo);
			}else if(customerExisting==null || customerExisting.getFuberEachCustomerMO()==null || customerExisting.getFuberEachCustomerMO().size()==0){
				customerExisting=new FuberCustomerMOs();
				if(mo.getPhone()==null || "".equals(mo.getPhone().trim())){
					return;
				}
				customerExisting.getFuberEachCustomerMO().add(mo);
			}
			JAXBXMLParsers.writeXMLDataToFileCustomerMO(file, customerExisting);
		}		
	
	}
	public void addCustomer(FuberCustomerVO vo,boolean append) throws JAXBException, IOException{
		FuberEachCustomerMO mo = MOVOConvertor.getMOFromVO(vo);
		addCustomer(mo, append);
	}
	
	private boolean checkUniquenessOfCustomer(List<FuberEachCustomerMO> fuberEachCustomerMO, FuberEachCustomerMO mo) {
		if(fuberEachCustomerMO==null || fuberEachCustomerMO.size()==0){
			return true;
		}
		for(int i=0;i<fuberEachCustomerMO.size();i++){
			if(fuberEachCustomerMO.get(i).getPhone()!=null && mo.getPhone()!=null && fuberEachCustomerMO.get(i).getPhone().equalsIgnoreCase(mo.getPhone())){
				return false;
			}
		}
		return true;
		
	}
	public void addCab(FuberEachCabMO mo, boolean append) throws JAXBException, IOException{
		File file=null;
		if(FuberUtils.getInstance().getDataSource()!=null && FuberUtils.getInstance().getDataSource() instanceof FileDataSourceImpl){
			 file=((FileDataSourceImpl)FuberUtils.getInstance().getDataSource()).getCabDataFile();
		}
		if(!append){
			FuberCabsMO mos=new FuberCabsMO();
			mos.getCabs().add(mo);
			JAXBXMLParsers.writeXMLDataToFileCabsMO(file, mos);
		}else{
			FuberCabsMO cabsExisting = FuberUtils.getInstance().getFuberCabMOFromDataStore();
			if(cabsExisting!=null && cabsExisting.getCabs()!=null && cabsExisting.getCabs().size()>0 && checkUniquenessOfCab(cabsExisting.getCabs(),mo)){
				cabsExisting.getCabs().add(mo);
			}else if(cabsExisting==null || cabsExisting.getCabs()==null || cabsExisting.getCabs().size()==0){
				cabsExisting=new FuberCabsMO();
				if(mo.getCabNumber()==null || "".equals(mo.getCabNumber().trim())){
					return;
				}
				cabsExisting.getCabs().add(mo);
			}
			JAXBXMLParsers.writeXMLDataToFileCabsMO(file, cabsExisting);
		}		
		
	}
	
	public String assignCab(FuberCustomerVO fuberCustomerVO,FuberCabVO nearestCab) throws IOException {
		startTime=System.currentTimeMillis();
		String response="";
		if(nearestCab!=null){
			String cabNumber=nearestCab.getCabNumber();
			if(cabNumber!=null && !cabNumber.trim().equals("")){
				try {
					boolean flag=false;
					if(getListOfAvailableCabsVO()!=null && getListOfAvailableCabsVO().size()>0){
						for(int i=0;i<getListOfAvailableCabsVO().size() && flag==false;i++){
							FuberCabVO cab = getListOfAvailableCabsVO().get(i);
							if(cab.getCabNumber()!=null && cab.getCabNumber().equalsIgnoreCase(nearestCab.getCabNumber())){
								nearestCab.setCabCoordinates(cab.getCabCoordinates());
								nearestCab.setCabType(cab.getCabType());
								nearestCab.setDriverLicense(cab.getDriverLicense());
								nearestCab.setDriverName(cab.getDriverName());
								nearestCab.setStatus(CabStatusVO.Running);
								FuberEachCabMO mo=MOVOConvertor.getMOFromVO(nearestCab);  //works till here
								updateCabData(mo,false);
								flag=true;
								response= "Assigned Cab Successfully";
							}
						}
					}
					if(!flag){
						response="Unable to Assign Cab "+cabNumber;
					}else{
						fuberCustomerVO.setAssignedCab(nearestCab);
						updateCustomerData(fuberCustomerVO,false);
					}
				} catch (JAXBException e) {
					response="Error in Assigning Cab";
				}
			}
		}else{
			response="No Cabs Available. Check if you have input coordinates";
			//request.setAttribute("nearestCab","No Cabs Available. Check if you have input coordinates");
		}
		return response;
	}
	
	public String releaseCab(FuberCustomerVO fuberCustomerVO) throws IOException {
		endTime=System.currentTimeMillis();
		String response="";
		try {
			List<FuberCustomerVO>customers=getListOfAvailableCustoemerVO();
			updateCustomerData(fuberCustomerVO,false);
			FuberCabVO assignedCab=null;
			int index=-1;
			if(customers!=null){
				for(int i=0;i<customers.size();i++){
					if(customers.get(i).getEndLocation()!=null && customers.get(i).getPhone().equalsIgnoreCase(fuberCustomerVO.getPhone())){
						 assignedCab = customers.get(i).getAssignedCab();
						 index=i;
						 break;
					}
				}
			}
			if(assignedCab!=null && index>=0){
				assignedCab.setCabCoordinates(new GeoLocationVO(customers.get(index).getEndLocation().getLatitude(), customers.get(index).getEndLocation().getLongitude()));
				float lat1=customers.get(index).getEndLocation().getLatitude();
				float lng1=customers.get(index).getEndLocation().getLongitude();
				float lat2=customers.get(index).getStartLocation().getLatitude();
				float lng2=customers.get(index).getStartLocation().getLongitude();
				float distance=getDistanceBetweenTwoCoordinates(lat1, lng1, lat2, lng2);
				float price=(distance/1000)*GlobalConstants.PRICE_PER_KM;
				price=price+((endTime-startTime)/(1000*60))*GlobalConstants.PRICE_PER_MIN;
				response=price+" "+GlobalConstants.UNIT;
				assignedCab.setStatus(CabStatusVO.Active);
				updateCabData(assignedCab,false);					
			}				
		} catch (JAXBException e) {
			response= "Unable to Release Cab";
		}
		return response;
	}

	
	public void addCabs(FuberCabsMO mo,boolean append) throws JAXBException, IOException{
		File file=null;
		
		if(FuberUtils.getInstance().getDataSource()!=null && FuberUtils.getInstance().getDataSource() instanceof FileDataSourceImpl){
			 file=((FileDataSourceImpl)FuberUtils.getInstance().getDataSource()).getCabDataFile();
		}
		if(!append){
			JAXBXMLParsers.writeXMLDataToFileCabsMO(file, mo);
		}
		else{
		FuberCabsMO cabsExisting = FuberUtils.getInstance().getFuberCabMOFromDataStore();
		if(cabsExisting!=null && cabsExisting.getCabs()!=null && cabsExisting.getCabs().size()>0){
			for(int i=0;i<mo.getCabs().size();i++){
				if(checkUniquenessOfCab(cabsExisting.getCabs(), mo.getCabs().get(i))){
					cabsExisting.getCabs().add(mo.getCabs().get(i));
				}
			}
		}else if(cabsExisting==null || cabsExisting.getCabs()==null || cabsExisting.getCabs().size()==0){
			cabsExisting=new FuberCabsMO();
			for(int i=0;i<mo.getCabs().size();i++){
				if(checkUniquenessOfCab(cabsExisting.getCabs(), mo.getCabs().get(i))){
					cabsExisting.getCabs().add(mo.getCabs().get(i));
				}
			}
		}
		JAXBXMLParsers.writeXMLDataToFileCabsMO(file, cabsExisting);
		}
	}
	public void removeCab(FuberCabVO vo) throws JAXBException, IOException{
		FuberEachCabMO mo=MOVOConvertor.getMOFromVO(vo);
		removeCab(mo);
		
	}
	public boolean removeCab(FuberEachCabMO mo) throws JAXBException, IOException{
		if(mo==null){
			return false;
		}
		if(mo.getCabNumber()==null || mo.getDriverLicense()==null || "".equals(mo.getCabNumber().trim()) || "".equals(mo.getDriverLicense().trim()))
		{
			return false;
		}
		FuberCabsMO cabsExisting = FuberUtils.getInstance().getFuberCabMOFromDataStore();
		if(cabsExisting==null || cabsExisting.getCabs()==null || cabsExisting.getCabs().size()==0){
			return false;
		}
		for(int i=0;i<cabsExisting.getCabs().size();i++){
			FuberEachCabMO cabInMO = cabsExisting.getCabs().get(i);
			if(cabInMO!=null && cabInMO.getCabNumber()!=null && mo.getCabNumber().equalsIgnoreCase(cabInMO.getCabNumber())
					&& cabInMO.getDriverLicense()!=null && cabInMO.getDriverLicense().equalsIgnoreCase(mo.getDriverLicense())){
				cabsExisting.getCabs().remove(i);
				File file=null;				
				if(FuberUtils.getInstance().getDataSource()!=null && FuberUtils.getInstance().getDataSource() instanceof FileDataSourceImpl){
					 file=((FileDataSourceImpl)FuberUtils.getInstance().getDataSource()).getCabDataFile();
				}
				addCabs(cabsExisting,false);  //we dont want to append, as it is update operation
				return true;
			}			
		}
		return false;
		
	}
	public boolean updateCustomerData(FuberCustomerVO vo, boolean addIfNotExist) throws JAXBException, IOException{
		FuberEachCustomerMO mo = MOVOConvertor.getMOFromVO(vo);
		updateCustomerData(mo,addIfNotExist);
		return true;
	}

	public boolean updateCustomerData(FuberEachCustomerMO mo,boolean addIfNotExist) throws JAXBException, IOException{
		File file=null;
		if(mo==null || mo.getPhone()==null || "".contentEquals(mo.getPhone().trim())){
			return false;
		}
		if(FuberUtils.getInstance().getDataSource()!=null && FuberUtils.getInstance().getDataSource() instanceof FileDataSourceImpl){
			 file=((FileDataSourceImpl)FuberUtils.getInstance().getDataSource()).getCustomerDataFile();
		}
		
		boolean flag=false;
		FuberCustomerMOs customerExisting = FuberUtils.getInstance().getFuberCustomerMOFromDataStore();
		if(customerExisting!=null && customerExisting.getFuberEachCustomerMO()!=null && customerExisting.getFuberEachCustomerMO().size()>0){
			for(int i=0;i<customerExisting.getFuberEachCustomerMO().size();i++){
				if(mo.getPhone().equalsIgnoreCase(customerExisting.getFuberEachCustomerMO().get(i).getPhone())){
					customerExisting.getFuberEachCustomerMO().remove(i);
					customerExisting.getFuberEachCustomerMO().add(mo);
					flag = true;
					break;
				}
			}
		}
		if(!flag && addIfNotExist){
			addCustomer(mo, true);
		}else if(flag){
			JAXBXMLParsers.writeXMLDataToFileCustomerMO(file, customerExisting);	
		}		
		return true;
	}
	public boolean updateCabData(FuberEachCabMO mo, boolean addifNotExist) throws JAXBException, IOException{
		File file=null;
		if(mo==null || mo.getCabNumber()==null || "".contentEquals(mo.getCabNumber().trim())){
			return false;
		}
		if(FuberUtils.getInstance().getDataSource()!=null && FuberUtils.getInstance().getDataSource() instanceof FileDataSourceImpl){
			 file=((FileDataSourceImpl)FuberUtils.getInstance().getDataSource()).getCabDataFile();
		}
		
		FuberCabsMO cabsExisting = FuberUtils.getInstance().getFuberCabMOFromDataStore();
		boolean flag=false;
		if(cabsExisting!=null && cabsExisting.getCabs()!=null && cabsExisting.getCabs().size()>0){
			for(int i=0;i<cabsExisting.getCabs().size();i++){
				if(mo.getCabNumber().equalsIgnoreCase(cabsExisting.getCabs().get(i).getCabNumber())){
					cabsExisting.getCabs().remove(i);
					cabsExisting.getCabs().add(mo);
					flag=true;
					break;
				}
			}
		}
		if(!flag && addifNotExist){
			addCab(mo,true);
		}else if(flag){
		JAXBXMLParsers.writeXMLDataToFileCabsMO(file, cabsExisting);
		}
		return true;
	}
	
	public boolean updateCabData(FuberCabVO vo,boolean addifNotExist) throws JAXBException, IOException{
		FuberEachCabMO mo = MOVOConvertor.getMOFromVO(vo);
		return updateCabData(mo,addifNotExist);
	}
	
	
}
