package cabs.fuber.controller;
import javax.xml.bind.JAXBException;

import cabs.fuber.model.data.mo.FuberCabsMO;
import cabs.fuber.model.data.mo.FuberCustomerMOs;
import cabs.fuber.view.vo.FuberCabVO;
import cabs.fuber.view.vo.FuberCustomerVO;

public class CabCustomerInitializer {
	FuberCabsMO fuberCabMO=null;
	FuberCustomerMOs fuberCustomerMO=null;
		
	FuberCabVO fuberCabVO=null;
	FuberCustomerVO fuberCustomerVO=null;
	private FuberUtils instance=FuberUtils.getInstance();
	
	
	public CabCustomerInitializer(){
		initialize();
	}
	
	public FuberCabsMO getFuberCabMO() {
		return fuberCabMO;
	}

	public void setFuberCabMO(FuberCabsMO fuberCabMO) {
		this.fuberCabMO = fuberCabMO;
	}

	public FuberCustomerMOs getFuberCustomerMO() {
		return fuberCustomerMO;
	}

	public void setFuberCustomerMO(FuberCustomerMOs fuberCustomerMO) {
		this.fuberCustomerMO = fuberCustomerMO;
	}

	public FuberCabVO getFuberCabVO() {
		return fuberCabVO;
	}

	public void setFuberCabVO(FuberCabVO fuberCabVO) {
		this.fuberCabVO = fuberCabVO;
	}

	public FuberCustomerVO getFuberCustomerVO() {
		return fuberCustomerVO;
	}

	public void setFuberCustomerVO(FuberCustomerVO fuberCustomerVO) {
		this.fuberCustomerVO = fuberCustomerVO;
	}

	public FuberUtils getInstance() {
		return instance;
	}

	public void setInstance(FuberUtils instance) {
		this.instance = instance;
	}

	public void initialize(){
		try {
			fuberCabMO=instance.getFuberCabMOFromDataStore();			
		} catch (JAXBException e) {
			//TODO log it
		}
		try {
			fuberCustomerMO=instance.getFuberCustomerMOFromDataStore();
		} catch (JAXBException e) {
			// TODO Auto-generated catch block
		}		
	}
	
	
	
}
