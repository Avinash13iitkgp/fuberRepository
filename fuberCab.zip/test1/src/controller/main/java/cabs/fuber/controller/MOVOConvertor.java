package cabs.fuber.controller;
import cabs.fuber.model.data.mo.CabStatusMO;
import cabs.fuber.model.data.mo.CabTypeMO;
import cabs.fuber.model.data.mo.FuberEachCabMO;
import cabs.fuber.model.data.mo.FuberEachCustomerMO;
import cabs.fuber.model.data.mo.GeoLocationMO;
import cabs.fuber.view.vo.CabStatusVO;
import cabs.fuber.view.vo.CabTypeVO;
import cabs.fuber.view.vo.FuberCabVO;
import cabs.fuber.view.vo.FuberCustomerVO;
import cabs.fuber.view.vo.GeoLocationVO;

public class MOVOConvertor {
	
	public static FuberEachCabMO getMOFromVO(FuberCabVO vo){
		if(vo==null){
			return null;
		}
		FuberEachCabMO mo=new FuberEachCabMO();
		if(vo.getCabCoordinates()!=null){
			GeoLocationMO cord=new GeoLocationMO(vo.getCabCoordinates().getLatitude(),vo.getCabCoordinates().getLongitude());
			mo.setCabCoordinates(cord);
		}
		if(vo.getCabType()!=null){
			CabTypeMO cabType=null;
			if(vo.getCabType().equals(CabTypeVO.Pink))
			{
				cabType=CabTypeMO.Pink;
			}
			else if(vo.getCabType().equals(CabTypeVO.Default)){
				cabType=CabTypeMO.Default;
			}
			mo.setCabType(cabType);
		}
		mo.setDriverLicense(vo.getDriverLicense());
		mo.setDriverName(vo.getDriverName());
		if(vo.getStatus()!=null){
			if(vo.getStatus().equals(CabStatusVO.Active)){
				mo.setStatus(CabStatusMO.Active);
			}
			if(vo.getStatus().equals(CabStatusVO.NotActive)){
				mo.setStatus(CabStatusMO.NotActive);
			}
			if(vo.getStatus().equals(CabStatusVO.Running)){
				mo.setStatus(CabStatusMO.Running);
			}
		}
		mo.setCabNumber(vo.getCabNumber());
		return mo;
	
	}

	public static FuberEachCustomerMO getMOFromVO(FuberCustomerVO vo){
		if(vo==null){
			return null;
		}
		FuberEachCustomerMO mo=new FuberEachCustomerMO();
		mo.setPhone(vo.getPhone());
		if(vo.getStartLocation()!=null){
			GeoLocationMO startLocation=new GeoLocationMO(vo.getStartLocation().getLatitude(), vo.getStartLocation().getLongitude());
			mo.setStartLocation(startLocation);
		}
		if(vo.getEndLocation()!=null){
			GeoLocationMO endLocation=new GeoLocationMO(vo.getEndLocation().getLatitude(), vo.getEndLocation().getLongitude());
			mo.setEndLocation(endLocation);
		}
		mo.setCustomerName(vo.getCustomerName());
		mo.setAssigned(vo.isAssigned());
		mo.setPhone(vo.getPhone());
		mo.setCab(MOVOConvertor.getMOFromVO(vo.getAssignedCab()));
		return mo;
	
		
	}
	public static FuberCabVO getVOFromMO(FuberEachCabMO mo){
		if(mo==null){
			return null;
		}
		FuberCabVO vo=new FuberCabVO();
		if(mo.getCabCoordinates()!=null){
			GeoLocationVO cabCoordinates=new GeoLocationVO(mo.getCabCoordinates().getLatitude(), mo.getCabCoordinates().getLongitude());
			vo.setCabCoordinates(cabCoordinates);
		}
		if(mo.getCabType()!=null){
			CabTypeVO cabType=null;
			if(mo.getCabType().equals(CabTypeMO.Pink))
			{
				cabType=CabTypeVO.Pink;
			}
			else if(mo.getCabType().equals(CabTypeMO.Default)){
				cabType=CabTypeVO.Default;
			}
			vo.setCabType(cabType);
		}
		vo.setDriverLicense(mo.getDriverLicense());
		vo.setDriverName(mo.getDriverName());
		if(mo.getStatus()!=null){
			if(mo.getStatus().equals(CabStatusMO.Active)){
				vo.setStatus(CabStatusVO.Active);
			}
			if(mo.getStatus().equals(CabStatusMO.NotActive)){
				vo.setStatus(CabStatusVO.NotActive);
			}
			if(mo.getStatus().equals(CabStatusMO.Running)){
				vo.setStatus(CabStatusVO.Running);
			}
		}
		vo.setCabNumber(mo.getCabNumber());
		
		return vo;
		
	}
	public static FuberCustomerVO getVOFromMO(FuberEachCustomerMO mo){
		if(mo==null){
			return null;
		}
		FuberCustomerVO vo=new FuberCustomerVO();
		if(mo.getStartLocation()!=null){
			GeoLocationVO startLocation=new GeoLocationVO(mo.getStartLocation().getLatitude(), mo.getStartLocation().getLongitude());
			vo.setStartLocation(startLocation);
		}
		if(mo.getEndLocation()!=null){
			GeoLocationVO endLocation=new GeoLocationVO(mo.getEndLocation().getLatitude(), mo.getEndLocation().getLongitude());
			vo.setEndLocation(endLocation);
		}
		vo.setCustomerName(mo.getCustomerName());
		vo.setAssigned(mo.isAssigned());
		vo.setPhone(mo.getPhone());
		vo.setAssignedCab(MOVOConvertor.getVOFromMO(mo.getCab()));
		return vo;
	
		
	}
}
