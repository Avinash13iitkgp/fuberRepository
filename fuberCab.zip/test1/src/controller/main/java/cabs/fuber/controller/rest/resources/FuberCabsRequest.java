package cabs.fuber.controller.rest.resources;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


@XmlRootElement(name="fuberCabsRequest")
@XmlType(propOrder={"driverName","driverLicense","cabType","cabCoordinates","status","cabNumber"})
public class FuberCabsRequest {
	String driverName=null;
	String driverLicense=null;
	String cabType;
	GeoLocation cabCoordinates=null;
	String status=null;
	String cabNumber=null;	
	
	public String getCabNumber() {
		return cabNumber;
	}
	public void setCabNumber(String cabNumber) {
		this.cabNumber = cabNumber;
	}
	public String getDriverName() {
		return driverName;
	}
	public void setDriverName(String driverName) {
		this.driverName = driverName;
	}
	public String getDriverLicense() {
		return driverLicense;
	}
	public void setDriverLicense(String driverLicense) {
		this.driverLicense = driverLicense;
	}
	
	public GeoLocation getCabCoordinates() {
		return cabCoordinates;
	}
	public void setCabCoordinates(GeoLocation cabCoordinates) {
		this.cabCoordinates = cabCoordinates;
	}
	public String getCabType() {
		return cabType;
	}
	public void setCabType(String cabType) {
		this.cabType = cabType;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
}
