package cabs.fuber.controller.listeners;

import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

import cabs.fuber.model.DataSourceFactoryImpl;
import cabs.fuber.model.DataSourceTypeEnum;

public class MySessionListener implements HttpSessionListener{

	@Override
	public void sessionCreated(HttpSessionEvent arg0) {
		DataSourceFactoryImpl dataSourceFactoryImpl=DataSourceFactoryImpl.getInstance();
		dataSourceFactoryImpl.getDataSource(DataSourceTypeEnum.File);		
	}

	@Override
	public void sessionDestroyed(HttpSessionEvent arg0) {
		// TODO Auto-generated method stub
		
	}

}
