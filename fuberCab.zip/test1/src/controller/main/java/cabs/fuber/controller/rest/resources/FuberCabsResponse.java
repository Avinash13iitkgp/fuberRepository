package cabs.fuber.controller.rest.resources;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


@XmlRootElement(name="fuberCabsResponse")
@XmlType(propOrder={"message"})
public class FuberCabsResponse {
	String message;

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
}
