package cabs.fuber.controller.listeners;

import java.util.logging.Logger;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import cabs.fuber.model.DataSourceFactoryImpl;
import cabs.fuber.model.DataSourceTypeEnum;

public class AppContextListener implements ServletContextListener{

	Logger log=Logger.getLogger("log.txt");
	
	@Override
	public void contextDestroyed(ServletContextEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void contextInitialized(ServletContextEvent arg0) {
		DataSourceFactoryImpl dataSourceFactoryImpl=DataSourceFactoryImpl.getInstance();
		dataSourceFactoryImpl.getDataSource(DataSourceTypeEnum.File);
		log.info("contextInitialized Avi");
	}

	
}
