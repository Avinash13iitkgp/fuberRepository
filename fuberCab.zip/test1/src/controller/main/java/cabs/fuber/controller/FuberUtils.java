package cabs.fuber.controller;
import java.io.File;

import javax.xml.bind.JAXBException;

import cabs.fuber.model.DataSourceFactoryImpl;
import cabs.fuber.model.DataSourceTypeEnum;
import cabs.fuber.model.data.mo.FuberCabsMO;
import cabs.fuber.model.data.mo.FuberCustomerMOs;
import cabs.fuber.model.datastore.interfaces.DataSource;
import cabs.fuber.model.datastore.interfaces.FuberDatastoreModel;
import cabs.fuber.model.datastores.impl.FileDatastoreModelImpl;
import cabs.fuber.model.datastores.impl.TestFileDatastoreModelImpl;

public class FuberUtils {
	private FuberDatastoreModel fuberDatastoreModel=null;
	private DataSource dataSource=null;
	private static FuberUtils instance=null;
	private JAXBXMLParsers parsers=new JAXBXMLParsers();
	private FuberUtils() {
		fuberDatastoreModel=new FileDatastoreModelImpl(DataSourceTypeEnum.File);
		dataSource=DataSourceFactoryImpl.getInstance().getDataSource(DataSourceTypeEnum.File);
	}
	
	public FuberDatastoreModel getFuberDatastoreModel() {
		return fuberDatastoreModel;
	}

	public void setFuberDatastoreModel(FuberDatastoreModel fuberDatastoreModel) {
		this.fuberDatastoreModel = fuberDatastoreModel;
	}

	public DataSource getDataSource() {
		return dataSource;
	}

	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}

	public JAXBXMLParsers getParsers() {
		return parsers;
	}

	public void setParsers(JAXBXMLParsers parsers) {
		this.parsers = parsers;
	}

	public static void setInstance(FuberUtils instance) {
		FuberUtils.instance = instance;
	}

	public synchronized static FuberUtils getInstance(){
		if(instance==null){
			instance=new FuberUtils();
		}
		return instance;
	}
	
	public FuberUtils(String type) {
		super();
		try {
			fuberDatastoreModel = new FileDatastoreModelImpl(DataSourceTypeEnum.getTypeFromDisplayValue(type));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
	}


	public FuberCabsMO getFuberCabMOFromDataStore() throws JAXBException {
		
		FuberCabsMO fuberCabMO=null;
		if(fuberDatastoreModel instanceof TestFileDatastoreModelImpl){
			File file=((FileDatastoreModelImpl)fuberDatastoreModel).getCabDataFile();
			if(file!=null && file.exists()){
				fuberCabMO=parsers.getCabMOFromXMLFile(file);
			}			
			
		}
		return fuberCabMO;
		
	}

	public FuberCustomerMOs getFuberCustomerMOFromDataStore() throws JAXBException {
		
		FuberCustomerMOs fuberCustomerMOs=null;
		if(fuberDatastoreModel instanceof TestFileDatastoreModelImpl){
			File file=((FileDatastoreModelImpl)fuberDatastoreModel).getCustomerDataFile();
			if(file!=null && file.exists()){
				fuberCustomerMOs=parsers.getCustomerMOsFromXmlFile(file);
			}						
		}
		return fuberCustomerMOs;
		
	}
	
}
