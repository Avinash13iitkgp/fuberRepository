package cabs.fuber.controller;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

import cabs.fuber.model.data.mo.FuberCabsMO;
import cabs.fuber.model.data.mo.FuberCustomerMOs;

public class JAXBXMLParsers {

	public FuberCabsMO getCabMOFromXMLFile(File file) throws JAXBException{
		FuberCabsMO fuberCabMO=null;
		JAXBContext jaxbContext = JAXBContext.newInstance(FuberCabsMO.class);  
		Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();  
	    fuberCabMO= (FuberCabsMO) jaxbUnmarshaller.unmarshal(file);  	   
	    return fuberCabMO;	       
	}
	
	public static void writeXMLDataToFileCabsMO(File file, FuberCabsMO mo) throws JAXBException, IOException{
		JAXBContext contextObj = JAXBContext.newInstance(FuberCabsMO.class);  	    
	    Marshaller marshallerObj = contextObj.createMarshaller();  
	    marshallerObj.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);  
	    if(!file.exists()){
	    	file.createNewFile();
	    }
	    marshallerObj.marshal(mo, new FileOutputStream(file.getAbsoluteFile()));
	    System.out.println(file.getAbsolutePath());
	}
	
	
	
	public FuberCustomerMOs getCustomerMOsFromXmlFile(File file) throws JAXBException{
		FuberCustomerMOs fuberCustomerMOs=null;
		JAXBContext jaxbContext = JAXBContext.newInstance(FuberCustomerMOs.class);  
		Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();  
		fuberCustomerMOs= (FuberCustomerMOs) jaxbUnmarshaller.unmarshal(file);  	   
	    return fuberCustomerMOs;	       
	}
	
	public static void writeXMLDataToFileCustomerMO(File file, FuberCustomerMOs mo) throws JAXBException, IOException{
		JAXBContext contextObj = JAXBContext.newInstance(FuberCustomerMOs.class);  	    
	    Marshaller marshallerObj = contextObj.createMarshaller();  
	    marshallerObj.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);  
	    if(!file.exists()){
	    	file.createNewFile();
	    }
	    marshallerObj.marshal(mo, new FileOutputStream(file.getAbsoluteFile()));
	    System.out.println(file.getAbsolutePath());
	}
}
