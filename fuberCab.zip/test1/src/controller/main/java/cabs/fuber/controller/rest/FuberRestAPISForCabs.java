package cabs.fuber.controller.rest;

import java.io.IOException;
import java.util.Enumeration;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.xml.bind.JAXBException;

import cabs.fuber.controller.FuberEventHandler;
import cabs.fuber.controller.rest.resources.FuberCabsRequest;
import cabs.fuber.controller.rest.resources.FuberCabsResponse;
import cabs.fuber.model.GlobalConstants;
import cabs.fuber.view.vo.CabStatusVO;
import cabs.fuber.view.vo.CabTypeVO;
import cabs.fuber.view.vo.FuberCabVO;
import cabs.fuber.view.vo.GeoLocationVO;

@Path("/cabs")
public class FuberRestAPISForCabs {
	Logger logger=Logger.getLogger(GlobalConstants.LOG_REST_FILE_PATH);
	@PUT
	@Produces({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
	@Consumes({MediaType.APPLICATION_XML,MediaType.APPLICATION_JSON})
	@Path("/")
	public Response addCabs(FuberCabsRequest request){
		FuberCabVO vo=new FuberCabVO();
		FuberCabsResponse fuberCabsResponse=new FuberCabsResponse();
		FuberEventHandler fuberEventHandler=new FuberEventHandler();
		
		vo.setCabNumber(request.getCabNumber());
		GeoLocationVO geoLocationVO=new GeoLocationVO(request.getCabCoordinates().getLatitude(),request.getCabCoordinates().getLongitude());
		vo.setCabCoordinates(geoLocationVO);
		vo.setDriverName(request.getDriverName());
		vo.setDriverLicense(request.getDriverLicense());
		if("pink".equalsIgnoreCase(request.getCabType())){
			vo.setCabType(CabTypeVO.Pink);
		}else{
			vo.setCabType(CabTypeVO.Default);
		}
		vo.setStatus(CabStatusVO.Active);
		try{
			fuberEventHandler.addCab(vo,true);
			fuberCabsResponse.setMessage("Added cab successfully");
		}catch(Exception e){
			logger.log(Level.ALL, e.getMessage());
			fuberCabsResponse.setMessage("Error in adding cab. "+e.getMessage());
		}
		return Response.status(201).entity(fuberCabsResponse).build();
		
	}
	
	
	@DELETE
	@Produces({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
	@Path("/")
	public Response removeAllCabs(){
		FuberCabsResponse response=new FuberCabsResponse();
		FuberEventHandler fuberEventHandler=new FuberEventHandler();
		
		try {
			try {
				fuberEventHandler.removeAllCabs();
			} catch (IOException e) {
				logger.log(Level.ALL, e.getStackTrace().toString());
				response.setMessage("Failed");
			}
			response.setMessage("Successfully removed all cabs");
		} catch (JAXBException e) {
			logger.log(Level.ALL, e.getMessage());
			response.setMessage("Exception Occurred while removing all cabs");
		}
		return Response.status(200).entity(response).build();
		
	}
	
	@GET
	@Produces({MediaType.TEXT_HTML})
	@Path("/")
	public Response sayHello(){
		String output = "Jersey say : ";
		return Response.status(200).entity(output).build();
	}

}
