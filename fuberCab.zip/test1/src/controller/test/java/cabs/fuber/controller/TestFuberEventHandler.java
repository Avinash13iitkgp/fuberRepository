package cabs.fuber.controller;

import static org.junit.Assert.*;

import java.io.IOException;

import javax.xml.bind.JAXBException;

import org.junit.Test;

import cabs.fuber.view.vo.CabStatusVO;
import cabs.fuber.view.vo.CabTypeVO;
import cabs.fuber.view.vo.FuberCabVO;
import cabs.fuber.view.vo.FuberCustomerVO;
import cabs.fuber.view.vo.GeoLocationVO;

public class TestFuberEventHandler {
	FuberEventHandler eventHandler=new FuberEventHandler();
	@Test
	public void testAddCab(){
		FuberCabVO cab=new FuberCabVO();
		cab.setCabCoordinates(new GeoLocationVO(33f,23f));
		cab.setCabNumber("UP1");
		cab.setCabType(CabTypeVO.Pink);
		cab.setDriverLicense("DL1");
		cab.setDriverName("Driver1");
		cab.setStatus(CabStatusVO.Active);
		
		try {
			eventHandler.addCab(cab, true);
		} catch (JAXBException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			assertEquals(eventHandler.getListOfAvailableCabsVO().size(),1);
		} catch (JAXBException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				eventHandler.removeAllCabs();
			} catch (JAXBException | IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	@Test
	public void testGetNearestCab()throws RuntimeException{
		FuberCustomerVO vo=new FuberCustomerVO();
		vo.setStartLocation(new GeoLocationVO(23f, 45f));
		assertEquals(null,eventHandler.getNearestCab(vo));	  		
	}
	
	@Test
	public void testRemoveAll(){
		
		try {
			eventHandler.removeAllCabs();
		} catch (JAXBException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			assertEquals(eventHandler.getListOfAvailableCabsVO().size(),0);
		} catch (JAXBException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				eventHandler.removeAllCabs();
			} catch (JAXBException | IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	public void testRelease(){
		
		FuberCabVO cab=new FuberCabVO();
		cab.setCabCoordinates(new GeoLocationVO(33f,23f));
		cab.setCabNumber("UP1");
		cab.setCabType(CabTypeVO.Pink);
		cab.setDriverLicense("DL1");
		cab.setDriverName("Driver1");
		cab.setStatus(CabStatusVO.Active);
		
		try {
			eventHandler.addCab(cab, true);
		} catch (JAXBException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			assertEquals(eventHandler.getListOfAvailableCabsVO().size(),1);
		} catch (JAXBException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		FuberCustomerVO vo=new FuberCustomerVO();
		vo.setStartLocation(new GeoLocationVO(23f, 45f));
		vo.setEndLocation(new GeoLocationVO(34f,76f));
		eventHandler.getNearestCab(vo);
	}
}