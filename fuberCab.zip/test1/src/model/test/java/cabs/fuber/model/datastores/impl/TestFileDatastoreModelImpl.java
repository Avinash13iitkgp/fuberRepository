package cabs.fuber.model.datastores.impl;

import static org.junit.Assert.*;

import java.io.IOException;

import org.junit.Test;

import cabs.fuber.model.DataSourceTypeEnum;

public class TestFileDatastoreModelImpl {

	private FileDatastoreModelImpl datastoreModelImpl=new FileDatastoreModelImpl(DataSourceTypeEnum.File);
	
	@Test
	public  void testGetCabData(){
		try {
			datastoreModelImpl.getCabData();
			assert(true);
		} catch (IOException e) {
			assert(false);
		}
	}
	@Test
	public  void testGetCustomerDataFile(){
		assertNotNull(datastoreModelImpl.getCustomerDataFile());
	}
	
	@Test
	public  void testGetCabDataFile(){
		assertNotNull(datastoreModelImpl.getCabDataFile());
	}
	
	@Test
	public  void testType(){
		assertEquals(datastoreModelImpl.getType(),DataSourceTypeEnum.File);
	}
}
