package cabs.fuber.model.utils;

import java.util.HashMap;
import java.util.Map;

public class EnumUtil {
	static Map<String, Object> displayValueWiseObjects = new HashMap<String, Object>();
	private static final String DELIMETER = "##";
	
	@SuppressWarnings("rawtypes")
	public static void init(Class clazz, Object object, String displayValue, String mdsValue) {
		displayValueWiseObjects.put(clazz.getSimpleName() + DELIMETER + displayValue, object);
	}
	
	public static <T> T getEnumFromMDSValue(Class<T> clazz, String displayValue) throws Exception{
		if (displayValue == null) {
			return null;
		}
		T t = (T) displayValueWiseObjects.get(clazz.getSimpleName() + DELIMETER + displayValue);
		if (t == null) {
			throw new NullPointerException(clazz.getSimpleName());
		}
		return t;
	}
	@SuppressWarnings("unchecked")
	public static <T> T getEnumFromDisplayValue(Class<T> clazz, String displayValue) throws Exception {
		if (displayValue == null) {
			return null;
		}
		T t = (T) displayValueWiseObjects.get(clazz.getSimpleName() + DELIMETER + displayValue);
		if (t == null) {
			throw new NullPointerException(clazz.getSimpleName());
		}
		return t;
	}

}
