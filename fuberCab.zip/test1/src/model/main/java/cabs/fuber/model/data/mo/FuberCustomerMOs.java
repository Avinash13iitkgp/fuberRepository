package cabs.fuber.model.data.mo;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name="fuberCustomerMOs")
@XmlType(propOrder={"fuberEachCustomerMO"})
public class FuberCustomerMOs {	
	private List<FuberEachCustomerMO> fuberEachCustomerMO=new ArrayList<FuberEachCustomerMO>();
	
	public FuberCustomerMOs() {
	}
	
	public List<FuberEachCustomerMO> getFuberEachCustomerMO() {
		return fuberEachCustomerMO;
	}
	public void setFuberEachCustomerMO(List<FuberEachCustomerMO> fuberEachCustomerMO) {
		this.fuberEachCustomerMO = fuberEachCustomerMO;
	}	
}
