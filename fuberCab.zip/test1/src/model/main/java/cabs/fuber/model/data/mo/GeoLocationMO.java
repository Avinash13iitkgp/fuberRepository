package cabs.fuber.model.data.mo;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name="geoLocation")
@XmlType(propOrder={"latitude","longitude"})
public class GeoLocationMO {
	float latitude;
	float longitude;
	
	public GeoLocationMO(){
		
	}
	
	public GeoLocationMO(float latitude, float longitude) {
		super();
		this.latitude = latitude;
		this.longitude = longitude;
	}
	
	public float getLatitude() {
		return latitude;
	}
	public void setLatitude(float latitude) {
		this.latitude = latitude;
	}
	public float getLongitude() {
		return longitude;
	}
	public void setLongitude(float longitude) {
		this.longitude = longitude;
	}
}
