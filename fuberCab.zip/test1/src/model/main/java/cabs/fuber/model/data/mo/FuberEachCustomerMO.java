package cabs.fuber.model.data.mo;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name="customerMO")
@XmlType(propOrder={"customerName","phone","startLocation","endLocation","assigned","cab"})
public class FuberEachCustomerMO {
	private String customerName=null;
	private String phone=null;
	private GeoLocationMO startLocation=null;
	private GeoLocationMO endLocation=null;
	boolean assigned=false;
	private FuberEachCabMO cab=null;
	
	public FuberEachCabMO getCab() {
		return cab;
	}
	public void setCab(FuberEachCabMO cab) {
		this.cab = cab;
	}
	public FuberEachCustomerMO(){
		
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	
	public boolean isAssigned() {
		return assigned;
	}
	public void setAssigned(boolean assigned) {
		this.assigned = assigned;
	}
	public GeoLocationMO getStartLocation() {
		return startLocation;
	}
	public void setStartLocation(GeoLocationMO startLocation) {
		this.startLocation = startLocation;
	}
	public GeoLocationMO getEndLocation() {
		return endLocation;
	}
	public void setEndLocation(GeoLocationMO endLocation) {
		this.endLocation = endLocation;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	
}
