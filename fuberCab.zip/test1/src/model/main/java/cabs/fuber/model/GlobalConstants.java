package cabs.fuber.model;

public class GlobalConstants {
	public static final String CAB_DATA_FILE="cabDataFile.xml";
	public static final String CUSTOMER_DATA_FILE="customerDataFile.xml";
	public static final float PRICE_PER_KM=2.0f;
	public static final float PRICE_PER_MIN=1.0f;
	public static final String UNIT="dogecoin";
	public static final String LOG_REST_FILE_PATH ="rest-api-logs.log";
	public static final String LOG_SERVLET_FILE_PATH = "servlet-logs.log";
	public static final String LOG_FILE = "application-logs.log";
}
