package cabs.fuber.model.data.mo;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name="fuberCab")
@XmlType(propOrder={"driverName","cabNumber","cabType","cabCoordinates","status","driverLicense"})
public class FuberEachCabMO {	
	String driverName=null;
	String cabNumber=null;
	CabTypeMO cabType;
	GeoLocationMO cabCoordinates=null;
	CabStatusMO status=null;
	String driverLicense=null;
	
	
	public String getDriverName() {
		return driverName;
	}
	public void setDriverName(String driverName) {
		this.driverName = driverName;
	}
	public String getDriverLicense() {
		return driverLicense;
	}
	public void setDriverLicense(String driverLicense) {
		this.driverLicense = driverLicense;
	}
	public CabTypeMO getCabType() {
		return cabType;
	}
	public void setCabType(CabTypeMO cabType) {
		this.cabType = cabType;
	}
	
	@XmlAttribute
	public String getCabNumber() {
		return cabNumber;
	}
	public void setCabNumber(String cabNumber) {
		this.cabNumber = cabNumber;
	}
	public GeoLocationMO getCabCoordinates() {
		return cabCoordinates;
	}
	public void setCabCoordinates(GeoLocationMO cabCoordinates) {
		this.cabCoordinates = cabCoordinates;
	}
	public CabStatusMO getStatus() {
		return status;
	}
	public void setStatus(CabStatusMO status) {
		this.status = status;
	}	

}
