package cabs.fuber.model.data.mo;


import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name="fuberCabs")
@XmlType(propOrder={"cabs"})
public class FuberCabsMO {
	
	
	List<FuberEachCabMO> cabs=new ArrayList<FuberEachCabMO>();
	
	public FuberCabsMO() {
	}

	public List<FuberEachCabMO> getCabs() {
		return cabs;
	}

	public void setCabs(List<FuberEachCabMO> cabs) {
		this.cabs = cabs;
	}
	
}
