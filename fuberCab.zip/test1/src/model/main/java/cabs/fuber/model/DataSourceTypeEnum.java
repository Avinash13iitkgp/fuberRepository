package cabs.fuber.model;

import cabs.fuber.model.utils.EnumUtil;

public enum DataSourceTypeEnum {
	
	File("File","file");
	String dataSourceType;
	DataSourceTypeEnum(String displayValue,String mdsValue){
		this.dataSourceType=dataSourceType;		
		EnumUtil.init(DataSourceTypeEnum.class, this, displayValue, mdsValue);
	}
	public String getDataSourceType() {
		return dataSourceType;
	}
	public void setDataSourceType(String dataSourceType) {
		this.dataSourceType = dataSourceType;
	}
	
	public static DataSourceTypeEnum getTypeFromDisplayValue(String value)throws Exception{
		return EnumUtil.getEnumFromDisplayValue(DataSourceTypeEnum.class,value);
	}
	
	public static DataSourceTypeEnum getTypeFromMDSValue(String value)throws Exception{
		return EnumUtil.getEnumFromMDSValue(DataSourceTypeEnum.class,value);
	}
}
