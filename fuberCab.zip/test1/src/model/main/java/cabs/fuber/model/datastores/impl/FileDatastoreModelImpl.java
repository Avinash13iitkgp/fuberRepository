package cabs.fuber.model.datastores.impl;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import cabs.fuber.model.DataSourceFactoryImpl;
import cabs.fuber.model.DataSourceTypeEnum;
import cabs.fuber.model.datastore.interfaces.DataSource;
import cabs.fuber.model.datastore.interfaces.FuberDatastoreModel;

public class FileDatastoreModelImpl implements FuberDatastoreModel{
	
	private DataSourceTypeEnum type=null;
	private DataSource dataSource=null;
	private File cabDataFile=null;
	private File customerDataFile=null;
	public FileDatastoreModelImpl(DataSourceTypeEnum type){
		this.type=type;
		this.dataSource=DataSourceFactoryImpl.getInstance().getDataSource(type);		
		if(dataSource!=null){
			this.cabDataFile=((FileDataSourceImpl)(dataSource)).getCabDataFile();
			this.customerDataFile=((FileDataSourceImpl)(dataSource)).getCustomerDataFile();
		}
	}
	
		
	public File getCabDataFile() {
		return cabDataFile;
	}


	public void setCabDataFile(File cabDatFile) {
		this.cabDataFile = cabDatFile;
	}


	public File getCustomerDataFile() {
		return customerDataFile;
	}


	public void setCustomerDataFile(File customerDataFile) {
		this.customerDataFile = customerDataFile;
	}


	public DataSourceTypeEnum getType() {
		return type;
	}

	public void setType(DataSourceTypeEnum type) {
		this.type = type;
	}

	public DataSource getDataSource() {
		return dataSource;
	}

	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}

	@Override
	public String getCabData() throws IOException {
		BufferedReader reader=null;
		try {
					reader = new BufferedReader(new FileReader(cabDataFile));
				} catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			    String line = null;
			    StringBuilder stringBuilder = new StringBuilder();
			    String ls = System.getProperty("line.separator");
	
			    try {
			        while((line = reader.readLine()) != null) {
			            stringBuilder.append(line);
			            stringBuilder.append(ls);
			        }
	
			        return stringBuilder.toString();
			    } finally {
			        reader.close();
			    }
	}

	@Override
	public boolean writeCabData(String data)throws IOException {
		BufferedWriter bw = null;
		FileWriter fw = null;
		try {
			String content = "";
			fw = new FileWriter(cabDataFile);
			bw = new BufferedWriter(fw);
			bw.write(content);
			return true;
			} catch (IOException e) {
				e.printStackTrace();
			}
			finally {
			try {
				if (bw != null)
					bw.close();
				if (fw != null)
					fw.close();
			} catch (IOException ex) {
				throw ex;
			}
		
			}
			return false;
		}
	@Override
	public boolean appendCabData(String data)throws IOException {
		BufferedWriter bw = null;
		FileWriter fw = null;
		try {
			String content = "";
			fw = new FileWriter(cabDataFile);
			bw = new BufferedWriter(fw);
			bw.append(content);
			return true;
			} catch (IOException e) {
				e.printStackTrace();
			}
			finally {
			try {
				if (bw != null)
					bw.close();
				if (fw != null)
					fw.close();
			} catch (IOException ex) {
				throw ex;
			}
		
			}
			return false;
		}	
}

