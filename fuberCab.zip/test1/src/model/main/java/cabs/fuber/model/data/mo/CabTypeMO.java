package cabs.fuber.model.data.mo;

public enum CabTypeMO {
	Pink("Pink","pink"),Default("Default","default");
	String mdsValue=null,displayValue=null;
	CabTypeMO(String displayValue,String mdsValue){
		this.displayValue=displayValue;
		this.mdsValue=mdsValue;
	}
	public String getMdsValue() {
		return mdsValue;
	}
	public void setMdsValue(String mdsValue) {
		this.mdsValue = mdsValue;
	}
	public String getDisplayValue() {
		return displayValue;
	}
	public void setDisplayValue(String displayValue) {
		this.displayValue = displayValue;
	}
	
}
