package cabs.fuber.model.datastores.impl;

import java.io.File;
import java.util.HashMap;
import java.util.Map;
import cabs.fuber.model.datastore.interfaces.DataSource;

public class FileDataSourceImpl implements DataSource {

	private File cabDataFile=null;
	private File customerDataFile=null;
	Map<String,String>properties =new HashMap<String, String>();
	
	public FileDataSourceImpl(Map<String,String>properties){	
		this.properties=properties;
		if(properties!=null){
			setDataSource();
		}
	}
	
	@Override
	public void setDataSource() {
		if(properties.containsKey("cabDataFile")){
			cabDataFile=new File((String)properties.get("cabDataFile"));
		}
		if(properties.containsKey("customerDataFile")){
			customerDataFile=new File((String)properties.get("customerDataFile"));
		}
	}

	@Override
	public Object getDataSource() {
		return cabDataFile;
	}

	public File getCabDataFile() {
		return cabDataFile;
	}

	public void setCabDataFile(File cabDataFile) {
		this.cabDataFile = cabDataFile;
	}

	public File getCustomerDataFile() {
		return customerDataFile;
	}

	public void setCustomerDataFile(File customerDataFile) {
		this.customerDataFile = customerDataFile;
	}

	public Map<String, String> getProperties() {
		return properties;
	}

	public void setProperties(Map<String, String> properties) {
		this.properties = properties;
	}	
}
