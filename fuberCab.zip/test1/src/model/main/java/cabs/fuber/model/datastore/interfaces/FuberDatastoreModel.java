package cabs.fuber.model.datastore.interfaces;

import java.io.IOException;

public interface FuberDatastoreModel {
	String getCabData() throws IOException;
	boolean writeCabData(String data) throws IOException;
	boolean appendCabData(String data) throws IOException;
}
