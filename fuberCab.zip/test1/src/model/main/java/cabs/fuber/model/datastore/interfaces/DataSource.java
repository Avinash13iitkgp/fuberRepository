package cabs.fuber.model.datastore.interfaces;

import java.util.Map;

public interface DataSource {
		void setDataSource();
		Object getDataSource();
}
