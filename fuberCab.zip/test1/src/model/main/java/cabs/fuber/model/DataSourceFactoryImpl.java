package cabs.fuber.model;

import java.util.HashMap;
import java.util.Map;

import cabs.fuber.model.datastore.interfaces.DataSource;
import cabs.fuber.model.datastores.impl.FileDataSourceImpl;

public class DataSourceFactoryImpl {
	static DataSourceFactoryImpl instance=null;
	private DataSource datasource=null;
	private DataSourceFactoryImpl(){
		initialize();
	}
	
	public static synchronized DataSourceFactoryImpl getInstance(){
		if(instance==null){
			instance=new DataSourceFactoryImpl();
		}
		return instance;
	}
	private void initialize(){
		
	}
	public DataSource getDataSource(DataSourceTypeEnum type){
		if(DataSourceTypeEnum.File.equals(type)){
			Map<String,String>properties=new HashMap<String, String>();
			properties.put("cabDataFile",GlobalConstants.CAB_DATA_FILE);
			properties.put("customerDataFile",GlobalConstants.CUSTOMER_DATA_FILE);
			datasource=new FileDataSourceImpl(properties);
		}
		return datasource;
	}

}
