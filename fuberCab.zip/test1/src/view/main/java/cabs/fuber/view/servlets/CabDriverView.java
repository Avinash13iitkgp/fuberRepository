package cabs.fuber.view.servlets;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.bind.JAXBException;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.DOMImplementation;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Text;


import cabs.fuber.controller.FuberEventHandler;
import cabs.fuber.model.GlobalConstants;
import cabs.fuber.view.util.XMLWriterDOM;
import cabs.fuber.view.vo.CabStatusVO;
import cabs.fuber.view.vo.CabTypeVO;
import cabs.fuber.view.vo.FuberCabVO;
import cabs.fuber.view.vo.GeoLocationVO;

public class CabDriverView extends HttpServlet{

	
		private Logger logger=Logger.getLogger(GlobalConstants.LOG_SERVLET_FILE_PATH);
		private static final long serialVersionUID = 1L;
		private String listOfCabs=null;
		private String nearestCab=null;
	    private TriggerPointHandler triggerPointHandler=new TriggerPointHandler();
	    /**
	     * @see HttpServlet#HttpServlet()
	     */
	    public CabDriverView() {
	        super();
	        // TODO Auto-generated constructor stub
	    }
	    
	    

		protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			response.setContentType("text/html");
		    String message = "Hello World";
		    request.setAttribute("message", "Hola Driver"); // This will be available as ${message}
		    request.getRequestDispatcher("/WEB-INF/driver.jsp").forward(request, response);
			
		}
		private static Document createEmptyDocument(String rootName) throws ParserConfigurationException {
	        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
	        DOMImplementation domImpl = dbf.newDocumentBuilder()
	                .getDOMImplementation();
	        Document document = domImpl.createDocument(null,rootName, null);
	        return document;
	    }

		protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			String licenceNumber = request.getParameter("licenceNumber");
			String cabNumber=request.getParameter("cabNumber");
			String latitudes=request.getParameter("latitude");
			String longitudes=request.getParameter("longitude");
			String name=request.getParameter("name");
			String cabType=request.getParameter("cabType");
			String xmlRequest="";
			
			Document document=getXMLRequestDocument("fuberCabsRequest",name,licenceNumber,cabType,latitudes,longitudes,cabNumber,"Running");
	        DOMSource dom=new DOMSource(document);
			StringWriter writer = new StringWriter();
			StreamResult result = new StreamResult(writer);
			
			TransformerFactory tf=TransformerFactory.newInstance();
			Transformer transformer = null;
			try {
				transformer = tf.newTransformer();
			} catch (TransformerConfigurationException e1) {
				logger.log(Level.ALL,e1.getMessage());
			}
			try {
				transformer.transform(dom, result);
			} catch (TransformerException e) {
				logger.log(Level.ALL,e.getMessage());
			}
			xmlRequest=writer.toString();
			
			
		    FuberEventHandler fuberEventHandler=new FuberEventHandler();
			if(request.getParameter("buttonRemoveAllCabs")!=null){
				String response1=triggerPointHandler.getDataFromDeleteRequest("cabs");
				request.setAttribute("message", getAttributeValueFromXMLResponse(response1));
			}
			if (request.getParameter("buttonSubmit") != null) {
				//addCabs(request, fuberEventHandler);
				String response1=triggerPointHandler.getDataFromPUTRequest("cabs",xmlRequest);
				request.setAttribute("message", getAttributeValueFromXMLResponse(response1));
			}
			request.getRequestDispatcher("/WEB-INF/driver.jsp").forward(request, response);
		 }
		
		private Document getXMLRequestDocument(String rootName,String driverNameV,String driverLicenseV, String cabTypeV, String latitudeV, String longitudeV, String cabNumberV, String statusV ) {
			Document document = null;
			try {
				document = createEmptyDocument(rootName);
			} catch (ParserConfigurationException e2) {
				logger.log(Level.ALL,e2.getMessage());
			}
	        Element root = document.getDocumentElement();
	        Element driverName=getElement(document, driverNameV, "driverName");
	        Element dl = getElement(document,driverLicenseV,"driverLicense");
	        Element type = getElement(document,cabTypeV,"cabType");
	        
	        Element cabCoordinates = document.createElement("cabCoordinates");
	        Element cabChildLat=getElement(document, latitudeV, "latitude");
	        Element cabChildLong=getElement(document, longitudeV, "longitude");
	        cabCoordinates.appendChild(cabChildLat);
	        cabCoordinates.appendChild(cabChildLong);
	        
	        Element status=getElement(document, statusV, "status");
	        Element cabNumber=getElement(document, cabNumberV, "cabNumber");
	        
	        root.appendChild(driverName);
	        root.appendChild(dl);
	        root.appendChild(type);
	        root.appendChild(cabCoordinates);
	        root.appendChild(status);
	        root.appendChild(cabNumber);
	        
	        return document;
		}

		private Element getElement(Document document, String value, String name){
			Element elem = document.createElement(name);
	        Text st = document.createTextNode(value);
	        elem.appendChild(st);
	        return elem;
		}

		public String getNearestCab() {
			return nearestCab;
		}

		public void setNearestCab(String nearestCab) {
			this.nearestCab = nearestCab;
		}

		public void setListOfCabs(String listOfCabs) {
			this.listOfCabs = listOfCabs;
		}
		
		String getAttributeValueFromXMLResponse(String xml){
			String response="";
			if(xml!=null){
				response=xml.substring(xml.indexOf("<message>")+9,xml.indexOf("</message>"));
			}
			return response;
		}
		

}