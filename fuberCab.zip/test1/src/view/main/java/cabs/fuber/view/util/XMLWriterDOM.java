package cabs.fuber.view.util;


import java.io.File;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
 
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
 
 
public class XMLWriterDOM {
 
 
    public static Document getCabDriver(Document doc,
    	String driverName, String driverLicense, String cabType,String latitude,String longitude, String status, String cabNumber) {
        Element driver = doc.createElement("fuberCabsRequest");
        doc.appendChild(driver);
        driver.appendChild(getCabDriverElement(doc,driver,"driverName", driverName));
        driver.appendChild(getCabDriverElement(doc, driver, "driverLicense", driverLicense));
        driver.appendChild(getCabDriverElement(doc, driver, "cabType", cabType));
        //driver.appendChild(getCabDriverElement(doc, driver, "cabCoordinates", cabCoordinates));
        Element geolocation=doc.createElement("geoLocation");
        driver.appendChild(geolocation);
        geolocation.appendChild(getCabDriverElement(doc,geolocation, "latitude",latitude));
        geolocation.appendChild(getCabDriverElement(doc,geolocation, "longitude",longitude));
        driver.appendChild(getCabDriverElement(doc, driver, "status", status));
        driver.appendChild(getCabDriverElement(doc, driver, "cabNumber", cabNumber));
        return doc;
    }
 
 
    //utility method to create text node
    private static Node getCabDriverElement(Document doc, Element element, String name, String value) {
        Element node = doc.createElement(name);
        node.appendChild(doc.createTextNode(value));
        return node;
    }
 
}
