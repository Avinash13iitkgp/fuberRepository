package cabs.fuber.view.vo;

public enum CabStatusVO {
	Active("active"),Running("running"),NotActive("notActive");
	String status;
	CabStatusVO(String status){
		this.status=status;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
}
