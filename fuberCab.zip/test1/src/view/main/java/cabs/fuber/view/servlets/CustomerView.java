package cabs.fuber.view.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.bind.JAXBException;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.DOMImplementation;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Text;

import cabs.fuber.controller.FuberEventHandler;
import cabs.fuber.controller.MOVOConvertor;
import cabs.fuber.model.GlobalConstants;
import cabs.fuber.model.data.mo.FuberEachCabMO;
import cabs.fuber.model.data.mo.FuberEachCustomerMO;
import cabs.fuber.view.enums.CustomerCabPreference;
import cabs.fuber.view.vo.CabStatusVO;
import cabs.fuber.view.vo.FuberCabVO;
import cabs.fuber.view.vo.FuberCustomerVO;
import cabs.fuber.view.vo.GeoLocationVO;

/**
 * Servlet implementation class FirstServlet
 */
public class CustomerView extends HttpServlet {
	private static final long serialVersionUID = 1L;
	long startTime;
	long endTime;
	  
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CustomerView() {
        super();
        // TODO Auto-generated constructor stub
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 response.setContentType("text/html");
	     
	     request.setAttribute("availableCabs", "Enter Your Coordinates To Process"); // This will be available as ${message}
	     request.setAttribute("nearestCab","Enter Your Details");
	     request.getRequestDispatcher("/WEB-INF/customer.jsp").forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		TriggerPointHandler triggerPointHandler=new TriggerPointHandler();
		String listOfCabs="No Cabs In Queue";
		String name= request.getParameter("name");
		String slatitudes=request.getParameter("slatitude");
		String slongitudes=request.getParameter("slongitude");
		String elatitudes=request.getParameter("elatitude");
		String elongitudes=request.getParameter("elongitude");
		String cabType=request.getParameter("cabType");
		String phone=request.getParameter("phone");
		String nearestCab=request.getParameter("nearestCab");
		Document document=getXMLRequestDocument("fuberCustomerRequest",name,phone,slatitudes,slongitudes,elatitudes,elongitudes,cabType);
        DOMSource dom=new DOMSource(document);
		StringWriter writer = new StringWriter();
		StreamResult result = new StreamResult(writer);
		
		TransformerFactory tf=TransformerFactory.newInstance();
		Transformer transformer = null;
		try {
			transformer = tf.newTransformer();
		} catch (TransformerConfigurationException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {
			transformer.transform(dom, result);
		} catch (TransformerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String xmlRequest = writer.toString();
		
		FuberEventHandler eventHandler=new FuberEventHandler();  //TODO remove
		
		if(request.getParameter("releaseCab")!=null){		
			String resp=triggerPointHandler.getDataFromPUTRequest("customers/release",xmlRequest);
			request.setAttribute("nearestCab",getAttributeValueFromXMLResponse(resp));
			
		}
		else if(request.getParameter("assignCab")!=null){
			String resp=triggerPointHandler.getDataFromPUTRequest("customers/assign",xmlRequest);
			request.setAttribute("nearestCab",getAttributeValueFromXMLResponse(resp));
		}else{
			try{
				triggerPointHandler.getDataFromPUTRequest("customers/update",xmlRequest);
			}catch(Exception e){
				//TODO nothing
			}
			try{
				String response1=triggerPointHandler.getDataFromGETRequest("customers");
				request.setAttribute("availableCabs",getAttributeValueFromXMLResponse(response1));
			}catch(Exception e){
				request.setAttribute("availableCabs","None. Update again. Error Occurred");
			}
//			updateTheAvailableCabsData(request, eventHandler);					
			try{
				String response2=triggerPointHandler.getDataFromPUTRequest("customers",xmlRequest);
				request.setAttribute("nearestCab",getAttributeValueFromXMLResponse(response2));
			}catch(Exception e){
				request.setAttribute("nearestCab","Nearest cab not found. Error.");
			}
			
			//updateNearestCab(request, eventHandler,nearestCab);			
		}
		request.getRequestDispatcher("/WEB-INF/customer.jsp").forward(request, response);
		
	}
	
	private String getCabDetails(FuberCabVO fuberCabVO) {
		if(fuberCabVO==null){
			return "";
		}
		String cab="";
		
		cab=cab+"[Cab Num:"+fuberCabVO.getCabNumber()+", License:"+fuberCabVO.getDriverLicense();
		if(fuberCabVO.getCabType()!=null){
			cab=cab+ ", Type: "+fuberCabVO.getCabType().getDisplayValue();
		}
		if(fuberCabVO.getDriverName()!=null && !"".equals(fuberCabVO.getDriverName())){
			cab=cab+", Name: "+fuberCabVO.getDriverName();
		}
		cab=cab+"]";
		return cab;
	}
	
	private Document getXMLRequestDocument(String rootName,String nameV,String phoneV, String slatV, String slongV,String llatV, String llongV, String cabPrefV ) {
		Document document = null;
		try {
			document = createEmptyDocument(rootName);
		} catch (ParserConfigurationException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
        Element root = document.getDocumentElement();
        Element driverName=getElement(document, nameV, "customerName");
        Element dl = getElement(document,phoneV,"phone");
        Element cabCoordinates = document.createElement(
        		"startLocation");
        Element cabChildLat=getElement(document, slatV, "latitude");
        Element cabChildLong=getElement(document, slongV, "longitude");
        cabCoordinates.appendChild(cabChildLat);
        cabCoordinates.appendChild(cabChildLong);
        
        Element cabCoordinatesE = document.createElement("endLocation");
        Element cabChildLatE=getElement(document, llatV, "latitude");
        Element cabChildLongE=getElement(document, llongV, "longitude");
        cabCoordinatesE.appendChild(cabChildLatE);
        cabCoordinatesE.appendChild(cabChildLongE);
        
        Element customerPreference=getElement(document, cabPrefV, "customerCabPreference");
        root.appendChild(driverName);
        root.appendChild(dl);
        root.appendChild(cabCoordinates);
;        root.appendChild(cabCoordinatesE);
        root.appendChild(customerPreference);
        return document;
	}

	private Element getElement(Document document, String value, String name){
		Element elem = document.createElement(name);
        Text st = document.createTextNode(value);
        elem.appendChild(st);
        return elem;
	}
	private static Document createEmptyDocument(String rootName) throws ParserConfigurationException {
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        DOMImplementation domImpl = dbf.newDocumentBuilder()
                .getDOMImplementation();
        Document document = domImpl.createDocument(null,rootName, null);
        return document;
    }
	
	String getAttributeValueFromXMLResponse(String xml){
		String response="";
		if(xml!=null && !"".equals(xml)){
			if((xml.indexOf("<message>")+9)<xml.length()){
			response=xml.substring(xml.indexOf("<message>")+9,xml.indexOf("</message>"));
			}
		}
		return response;
	}
	

}