package cabs.fuber.view.servlets;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.ws.rs.core.Response;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;

import cabs.fuber.model.GlobalConstants;

public class TriggerPointHandler {
	private static Logger logger=Logger.getLogger(GlobalConstants.LOG_FILE);
	public static String getDataFromPUTRequest(String path,String input) throws IOException{
	
		try{
		DefaultHttpClient httpClient = new DefaultHttpClient();
		HttpPut getRequest = new HttpPut("http://localhost:8081/test1/rest/"+path);
		getRequest.addHeader("accept", "application/xml");
		getRequest.addHeader("content-type", "application/xml");
		StringEntity params =new StringEntity(input,"UTF-8");
	    //params.setContentType("application/xml");
		
	    getRequest.setEntity(params);

		HttpResponse response = httpClient.execute(getRequest);

	
		if (!(response.getStatusLine().getStatusCode() >=200 && response.getStatusLine().getStatusCode()<205) ) {
			logger.log(Level.ALL, "In Trigger Event Handler failed with status code "+response.getStatusLine().getStatusCode());
			throw new RuntimeException("Failed : HTTP error code : "
			   + response.getStatusLine().getStatusCode());
		}

		BufferedReader br = new BufferedReader(
                         new InputStreamReader((response.getEntity().getContent())));

		String output="",out="";
		while ((out=br.readLine()) != null) {
			output=output+out+"\n";
		}

		httpClient.getConnectionManager().shutdown();
		return output;
	  } catch(ClientProtocolException e) {
		  logger.log(Level.ALL, "In Trigger Event Handler "+e.getMessage());
	  } catch (IOException e) {
		  logger.log(Level.ALL, "In Trigger Event Handler "+e.getMessage());
	  }
		return null;
		
 }

	public static String getDataFromGETRequest(String path) throws IOException{
		
		try{
		DefaultHttpClient httpClient = new DefaultHttpClient();
		HttpGet getRequest = new HttpGet("http://localhost:8081/test1/rest/"+path);
		getRequest.addHeader("accept", "application/xml");
		getRequest.addHeader("content-type", "application/xml");
		
		HttpResponse response = httpClient.execute(getRequest);
	
		if (!(response.getStatusLine().getStatusCode() >=200 && response.getStatusLine().getStatusCode()<205) ) {
			logger.log(Level.ALL, "In get data from get request failed with error code "+response.getStatusLine().getStatusCode());
			throw new RuntimeException("Failed : HTTP error code : "
			   + response.getStatusLine().getStatusCode());
		}

		BufferedReader br = new BufferedReader(
                         new InputStreamReader((response.getEntity().getContent())));

		String output="",out="";
		System.out.println("Output from Server .... \n");
		while ((out=br.readLine()) != null) {
			output=output+out+"\n";
		}

		httpClient.getConnectionManager().shutdown();
		return output;
	  } catch(ClientProtocolException e) {
		  logger.log(Level.ALL, "In get data from get request failed with "+e.getMessage());
	  } catch (IOException e) {
		  logger.log(Level.ALL, "In get data from get request failed with "+e.getMessage());
	  }
		return null;
		
 }

	
	public String getDataFromDeleteRequest(String path) throws IOException {
		try{
			DefaultHttpClient httpClient = new DefaultHttpClient();
			HttpDelete getRequest = new HttpDelete("http://localhost:8081/test1/rest/"+path);
					/*getRequest.addHeader("accept", "application/xml");*/
			getRequest.addHeader("content-type", "application/xml");
			getRequest.addHeader("accept", "application/xml");
			HttpResponse response = httpClient.execute(getRequest);
		
			if (!(response.getStatusLine().getStatusCode() >=200 && response.getStatusLine().getStatusCode()<205) ) {
				throw new RuntimeException("Failed : HTTP error code : "
				   + response.getStatusLine().getStatusCode());
			}

			BufferedReader br = new BufferedReader(
	                         new InputStreamReader((response.getEntity().getContent())));

			String output="",out="";
			System.out.println("Output from Server .... \n");
			while ((out=br.readLine()) != null) {
				output=output+out+"\n";
			}

			httpClient.getConnectionManager().shutdown();
			return output;
		  } catch(ClientProtocolException e) {
			  logger.log(Level.ALL, "In delete request "+e.getMessage());
		  } catch (IOException e) {
			  logger.log(Level.ALL, "In delete request "+e.getMessage());
		}
			return null;
			
	}
}
