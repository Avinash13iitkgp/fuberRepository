package cabs.fuber.view.enums;

public enum CustomerCabPreference {
	Pink("Pink","pink"),Default("Default","default");
	
	String displayValue, mdsValue;

	private CustomerCabPreference(java.lang.String displayValue, java.lang.String mdsValue) {
		this.displayValue = displayValue;
		mdsValue = mdsValue;
	}

	public String getDisplayValue() {
		return displayValue;
	}

	public void setDisplayValue(String displayValue) {
		this.displayValue = displayValue;
	}

	public String getMdsValue() {
		return mdsValue;
	}

	public void setMdsValue(String mdsValue) {
		this.mdsValue = mdsValue;
	} 
	

}
