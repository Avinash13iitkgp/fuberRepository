package cabs.fuber.view.vo;

import cabs.fuber.view.enums.CustomerCabPreference;

public class FuberCustomerVO {
	private String customerName=null;
	private GeoLocationVO startLocation=null;
	private GeoLocationVO endLocation=null;
	private boolean isAssigned;
	private CustomerCabPreference customerCabPreference=null;
	private FuberCabVO assignedCab=null;
	private String phone;
		
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public GeoLocationVO getStartLocation() {
		return startLocation;
	}
	public void setStartLocation(GeoLocationVO startLocation) {
		this.startLocation = startLocation;
	}
	public GeoLocationVO getEndLocation() {
		return endLocation;
	}
	public void setEndLocation(GeoLocationVO endLocation) {
		this.endLocation = endLocation;
	}
	public boolean isAssigned() {
		return isAssigned;
	}
	public void setAssigned(boolean isAssigned) {
		this.isAssigned = isAssigned;
	}
	public CustomerCabPreference getCustomerCabPreference() {
		return customerCabPreference;
	}
	public void setCustomerCabPreference(CustomerCabPreference customerCabPreference) {
		this.customerCabPreference = customerCabPreference;
	}
	public FuberCabVO getAssignedCab() {
		return assignedCab;
	}
	public void setAssignedCab(FuberCabVO assignedCab) {
		this.assignedCab = assignedCab;
	}	
}
