package cabs.fuber.view.vo;

import cabs.fuber.model.data.mo.CabStatusMO;
import cabs.fuber.model.data.mo.CabTypeMO;

public class FuberCabVO {	
	String driverName=null;
	String driverLicense=null;
	CabTypeVO cabType;
	GeoLocationVO cabCoordinates=null;
	CabStatusVO status=null;
	String cabNumber=null;	
	
	public String getCabNumber() {
		return cabNumber;
	}
	public void setCabNumber(String cabNumber) {
		this.cabNumber = cabNumber;
	}
	public String getDriverName() {
		return driverName;
	}
	public void setDriverName(String driverName) {
		this.driverName = driverName;
	}
	public String getDriverLicense() {
		return driverLicense;
	}
	public void setDriverLicense(String driverLicense) {
		this.driverLicense = driverLicense;
	}
	
	public GeoLocationVO getCabCoordinates() {
		return cabCoordinates;
	}
	public void setCabCoordinates(GeoLocationVO cabCoordinates) {
		this.cabCoordinates = cabCoordinates;
	}
	public CabTypeVO getCabType() {
		return cabType;
	}
	public void setCabType(CabTypeVO cabType) {
		this.cabType = cabType;
	}
	public CabStatusVO getStatus() {
		return status;
	}
	public void setStatus(CabStatusVO status) {
		this.status = status;
	}
	
}
