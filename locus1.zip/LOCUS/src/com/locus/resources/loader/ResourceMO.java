package com.locus.resources.loader;

import java.util.List;

public class ResourceMO {
		private List<Resources> resources;

	    
	    public List<Resources> getResources ()
	    {
	        return resources;
	    }

	    public void setResources (List<Resources> resources)
	    {
	        this.resources = resources;
	    }				
	
}
