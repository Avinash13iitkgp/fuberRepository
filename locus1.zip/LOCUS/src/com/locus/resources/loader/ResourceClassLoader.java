package com.locus.resources.loader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;


public class ResourceClassLoader {

	private static ResourceMO resourceMO;
	
	private static void generateResourceMOFromPolicyFile() throws JsonParseException, JsonMappingException, IOException {
		byte[] jsonData=null;
		try {
			jsonData = Files.readAllBytes(Paths.get("resources/resources.json"));
		} catch (IOException e) {
			e.printStackTrace();
		}				
		ObjectMapper objectMapper = new ObjectMapper();
		resourceMO = objectMapper.readValue(jsonData, ResourceMO.class);
	}

	public static ResourceMO getResourceMO() {
		try{
				generateResourceMOFromPolicyFile();  //everytime its called, generate the policy mo again
				return resourceMO;
				}catch(Exception e){
					e.printStackTrace();
					return null;
				}
		}
		

}
