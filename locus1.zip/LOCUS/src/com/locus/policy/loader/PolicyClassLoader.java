package com.locus.policy.loader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.DeserializationConfig.Feature;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;

public class PolicyClassLoader {
	
	private static PolicyMO policyMO;
	
	private static void generatePolicyMOFromPolicyFile() throws JsonParseException, JsonMappingException, IOException {
		byte[] jsonData=null;
		try {
			jsonData = Files.readAllBytes(Paths.get("resources/policy.json"));
		} catch (IOException e) {
			e.printStackTrace();
		}				
		ObjectMapper objectMapper = new ObjectMapper().disable(Feature.FAIL_ON_UNKNOWN_PROPERTIES);
		policyMO = objectMapper.readValue(jsonData, PolicyMO.class);
	}

	public static PolicyMO getPolicyMO() {
		try{
				generatePolicyMOFromPolicyFile();  //everytime its called, generate the policy mo again
				return policyMO;
				}catch(Exception e){
					e.printStackTrace();
					return null;
				}
		}
}
