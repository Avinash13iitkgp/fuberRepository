package com.locus.policy.loader;

import java.util.List;

public class RolesMO {

	private List<PolicyResourceMO> resources;  //A list of resources

	public List<PolicyResourceMO> getResources() {
		return resources;
	}

	public void setResources(List<PolicyResourceMO> resources) {
		this.resources = resources;
	}
		
}
