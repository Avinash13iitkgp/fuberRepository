package com.locus.policy.loader;

import java.util.List;
import java.util.Map;

public class PolicyMO {
	List<Map<String,RolesMO>> policy;

	public List<Map<String,RolesMO>> getPolicy() {
		return policy;
	}

	public void setPolicy(List<Map<String,RolesMO>> policy) {
		this.policy = policy;
	}

	@Override
	public String toString() {
		return "PolicyMO [policy=" + policy + "]";
	}
}
