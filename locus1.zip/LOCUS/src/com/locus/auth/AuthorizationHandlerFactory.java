package com.locus.auth;

public interface AuthorizationHandlerFactory {
	AuthorizationHandler getAuthorizationHandler(String type);
}
