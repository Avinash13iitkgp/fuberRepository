package com.locus.auth.main;


import com.locus.auth.AuthorizationHandler;
import com.locus.auth.AuthorizationHandlerFactory;
import com.locus.auth.impl.AuthorizationHandlerFactoryImpl;
import com.locus.auth.impl.RoleEnum;
import com.locus.auth.users.User;
import com.locus.auth.users.impl.LocusUserImpl;
import com.locus.auth.users.impl.PrivilegesEnum;
class UserRoleAuthenticationMain {

	public static void main(String[] args) {
		User user=new LocusUserImpl("Avinash");		
		AuthorizationHandlerFactory factory=new AuthorizationHandlerFactoryImpl();
		AuthorizationHandler authorizationHandler=factory.getAuthorizationHandler("locus");
		System.out.println("Expecting true for granting role of External User [Output: "+authorizationHandler.grantRole(user, RoleEnum.EXTERNAL.getRole())+"]");
		System.out.println("Expecting false for checking privilege of READ on resources/folder1  as only resources/folder2 accessible to External with Read Permissions [Output: "+authorizationHandler.checkPrivilegesOfUser(user,"resources/folder1",PrivilegesEnum.READ.getPrivilege(),"policy")+"]");
		System.out.println("Expecting false for checking privilege of READ on resources/folder3 as only resources/folder2 accessible to External with Read Permissions [Output: "+authorizationHandler.checkPrivilegesOfUser(user,"resources/folder3",PrivilegesEnum.READ.getPrivilege(),"policy")+"]");
		System.out.println("Expecting true for checking privilege of READ on resources/folder2 as only resources/folder2 accessible to External with Read Permissions [Output: "+authorizationHandler.checkPrivilegesOfUser(user,"resources/folder2",PrivilegesEnum.READ.getPrivilege(),"policy")+"]");
		System.out.println("Expecting false for checking privilege of WRITE on resources/folder2 as only resources/folder2 accessible to External with Read Permissions [Output: "+authorizationHandler.checkPrivilegesOfUser(user,"resources/folder2",PrivilegesEnum.WRITE.getPrivilege(),"policy")+"]");
		System.out.println("Expecting false for checking privilege of DELETE on resources/folder2 as only resources/folder2 accessible to External with Read Permissions [Output: "+authorizationHandler.checkPrivilegesOfUser(user,"resources/folder2",PrivilegesEnum.DELETE.getPrivilege(),"policy")+"]");
		System.out.println("Expecting true for checking privilege of READ on resources/folder2/abc as only resources/folder2/ accessible to External with Read Permissions [Output: "+authorizationHandler.checkPrivilegesOfUser(user,"resources/folder2/abc",PrivilegesEnum.READ.getPrivilege(),"policy")+"]");
		System.out.println("Expecting true for checking privilege of READ on resources/folder2/abc as only resources/folder2/ accessible to External with Read Permissions [Output: "+authorizationHandler.checkPrivilegesOfUser(user,"resources/folder2/abc",PrivilegesEnum.READ.getPrivilege(),"policy")+"]");
		System.out.println("Expecting false for checking privilege of DELETE on resources/folder2/abc as only resources/folder2/ accessible to External with Read Permissions [Output: "+authorizationHandler.checkPrivilegesOfUser(user,"resources/folder2/abc",PrivilegesEnum.DELETE.getPrivilege(),"policy")+"]");
		
		
		/*
		 * Granting one more permission of admin. This should give all access
		 */
		
		
		System.out.println("Expecting true for granting role of External User [Output: "+authorizationHandler.grantRole(user, RoleEnum.ADMIN.getRole())+"]");
		System.out.println("Expecting true for checking privilege of WRITE on resources/folder1 [Output: "+authorizationHandler.checkPrivilegesOfUser(user,"resources/folder1",PrivilegesEnum.WRITE.getPrivilege(),"policy")+"]");
		System.out.println("Expecting false for revoking Monitoring Role as no Monitoring role assigned [Output: "+authorizationHandler.revokeRole(user,RoleEnum.MONITOR.getRole())+"]");
		System.out.println("Expecting true for revoking ADMIN Role as ADMIN role is assigned [Output: "+authorizationHandler.revokeRole(user,RoleEnum.ADMIN.getRole())+"]");
		System.out.println("Expecting false for revoking ADMIN Role as ADMIN role already removed [Output: "+authorizationHandler.revokeRole(user,RoleEnum.ADMIN.getRole())+"]");
		System.out.println("Expecting false for checking privilege of WRITE on resources/folder1 [Output: "+authorizationHandler.checkPrivilegesOfUser(user,"resources/folder1",PrivilegesEnum.WRITE.getPrivilege(),"policy")+"]");
		
	
	}

}
