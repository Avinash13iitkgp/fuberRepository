package com.locus.auth.chain.responsibility;

import com.locus.auth.users.Role;
import com.locus.policy.loader.PolicyResourceMO;
import com.locus.policy.loader.RolesMO;

public interface PolicyChainOfResponsibility {
	void setNextChain(PolicyChainOfResponsibility next);
	boolean check(Role role, String path, String privilege,RolesMO specificPolicy, PolicyResourceMO policyResourceMO);
}
