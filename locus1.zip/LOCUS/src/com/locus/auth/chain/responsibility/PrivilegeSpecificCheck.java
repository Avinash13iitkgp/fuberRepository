package com.locus.auth.chain.responsibility;
import com.locus.auth.users.Role;
import com.locus.auth.users.impl.PrivilegesEnum;
import com.locus.policy.loader.PolicyResourceMO;
import com.locus.policy.loader.RolesMO;

public class PrivilegeSpecificCheck implements PolicyChainOfResponsibility {

	PolicyChainOfResponsibility next;
	@Override
	public void setNextChain(PolicyChainOfResponsibility next) {
		this.next=next;
	}

	@Override
	public boolean check(Role role, String path, String privilege,RolesMO specificPolicy, PolicyResourceMO policyResourceMO) {
		if(validatePrivileges(privilege,policyResourceMO)){
			return true;
		}
		return false;
	}

	private boolean validatePrivileges(String privilege, PolicyResourceMO policyResourceMO) {
		if(PrivilegesEnum.WRITE.getPrivilege().equalsIgnoreCase(privilege)){
			if(policyResourceMO.isWrite()){
				return true;
			}
			return false;
		}
		if(PrivilegesEnum.READ.getPrivilege().equalsIgnoreCase(privilege)){
			if(policyResourceMO.isRead()){
				return true;
			}
			return false;
		}
		if(PrivilegesEnum.DELETE.getPrivilege().equalsIgnoreCase(privilege)){
			if(policyResourceMO.isDelete()){
				return true;
			}
			return false;
		}
		return false;
	}

}
