package com.locus.auth.chain.responsibility;

public class ChainDispenserFactory {
	private PolicyChainOfResponsibility head;
	
	public PolicyChainOfResponsibility getChainHead(String type){
		if(type==null || "".equals(type)){
			return null;
		}
		switch(type){
			case "locus":
				head=new PolicySpecificCheck();
				PolicyChainOfResponsibility node2=new ResourceSpecificCheck();
				head.setNextChain(node2);
				PolicyChainOfResponsibility node3=new PrivilegeSpecificCheck();
				node2.setNextChain(node3);
				node3.setNextChain(null);
				return head;
				
			default:
				return null;
		}
	}
}
