package com.locus.auth.chain.responsibility;
import com.locus.auth.users.Role;
import com.locus.policy.loader.PolicyResourceMO;
import com.locus.policy.loader.RolesMO;

public class PolicySpecificCheck implements PolicyChainOfResponsibility {

	PolicyChainOfResponsibility next=null;
	@Override
	public void setNextChain(PolicyChainOfResponsibility next) {
		this.next=next;
	}

	@Override
	public boolean check(Role role, String path, String privilege,RolesMO specificPolicy,PolicyResourceMO policyResourceMO) {
		//call this for all roles assigned
		if(role==null || path==null || privilege==null || "".contentEquals(path) || "".contentEquals(privilege) || role.getRoleName()==null ||
				"".equals(role.getRoleName())){
			return false;
		}	
		if(specificPolicy==null){
			return false;
		}
		if(next!=null){
			return next.check(role, path, privilege, specificPolicy,null);
		}
		return false;
	}
}