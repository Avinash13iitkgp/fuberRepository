package com.locus.auth.chain.responsibility;

import java.util.List;

import com.locus.auth.users.Role;
import com.locus.policy.loader.PolicyResourceMO;
import com.locus.policy.loader.RolesMO;
import com.locus.resources.loader.ResourceClassLoader;
import com.locus.resources.loader.ResourceMO;
import com.locus.resources.loader.Resources;

public class ResourceSpecificCheck implements PolicyChainOfResponsibility {

	PolicyChainOfResponsibility next;
	@Override
	public void setNextChain(PolicyChainOfResponsibility next) {
		this.next=next;

	}

	@Override
	public boolean check(Role role, String path, String privilege, RolesMO specificPolicy,PolicyResourceMO policyResourceMO) {
		//since getting called from resource specific, we dont need to check null conditions
		if(specificPolicy==null){
			return false;
		}
		List<PolicyResourceMO> resources = specificPolicy.getResources();
		if(resources==null || resources.size()==0){
			return false;
		}
		boolean check=false;
		for(int i=0;i<resources.size();i++){
			check=checkIfResourceHasAccessToPath(resources.get(i),path);  //checks if resource has the path we are trying to access
			if(check){
				check=next.check(role, path, privilege, specificPolicy,resources.get(i));
				if(check)
					{
					return true;
					}
			}
		}
		return false;
		
	}

private boolean checkIfResourceHasAccessToPath(PolicyResourceMO policyResourceMO, String path) {
	ResourceMO resourceMO = ResourceClassLoader.getResourceMO();
	if(resourceMO==null || resourceMO.getResources()==null || resourceMO.getResources().size()==0 || policyResourceMO==null ||policyResourceMO.getResourceName()==null || "".equals(policyResourceMO.getResourceName())){
		return false;
	}
	List<Resources> resources = resourceMO.getResources();
	for(int i=0;i<resources.size();i++){
		if(policyResourceMO.getResourceName().equals(resources.get(i).getName())){
			List<String> folders = resources.get(i).getFolders();
			List<String> files = resources.get(i).getFiles();	
			if(checkIfExist(folders,path,true) || checkIfExist(files, path,false)){
				return true;
			}else{
				return false;
			}				
		}			
	}
	return false;
	
}

private boolean checkIfExist(List<String> folders, String path, boolean isFolder) {
	if(folders==null || folders.size()==0 || path==null || "".contentEquals(path)){
		return false;
	}
	for(int i=0;i<folders.size();i++){
		if(isFolder){
			if(path.startsWith(folders.get(i))){
				return true;
			}
		}
		else if(folders.get(i).equalsIgnoreCase(path)){
			return true;
		}
	}
	return false;
}

}