package com.locus.auth.users.impl;

import com.locus.auth.users.Role;

public class LocusRoleImpl implements Role {

	private String roleName;
	
	@Override
	public String getRoleName() {
		return roleName;
	}

	@Override
	public void setRoleName(String roleName) {
		this.roleName=roleName;		
	}
	

	@Override
	public boolean equals(Object obj){
		if(obj ==null)
			{
			return false;
			}
		if(obj instanceof LocusRoleImpl){
			LocusRoleImpl obj1 = (LocusRoleImpl)obj;
			if(obj1.getRoleName()==this.getRoleName()){
				return true;
			}
		}
		return false;
	}
}
