package com.locus.auth.users.impl;

import java.util.HashSet;
import java.util.Set;

import com.locus.auth.users.Role;
import com.locus.auth.users.User;

public class LocusUserImpl implements User {

	private String name;
	private Set<Role> roles;
	
	public LocusUserImpl(String name) {
		this.name=name;
		roles=new HashSet<Role>();
	}
	
	@Override
	public String getName() {
		return name;
	}

	@Override
	public void setName(String name) {
		this.name=name;
	}

	@Override
	public void setRoles(Set<Role> roles) {
		this.roles=roles;		
	}

	@Override
	public Set<Role> getRoles() {
		return roles;
	}

	@Override
	public void addRole(Role role) {
		roles.add(role);
	}

}
