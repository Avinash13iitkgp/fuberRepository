package com.locus.auth.users;

public interface Role {
	String getRoleName();
	void setRoleName(String roleName);
}
