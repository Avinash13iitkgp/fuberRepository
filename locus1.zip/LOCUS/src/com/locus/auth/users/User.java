package com.locus.auth.users;

import java.util.Set;

public interface User {
	String getName();
	void setName(String name);
	void setRoles(Set<Role> roles);
	Set<Role> getRoles();
	void addRole(Role role);		
}
