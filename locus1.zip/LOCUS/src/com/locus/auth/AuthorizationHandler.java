package com.locus.auth;

import com.locus.auth.users.User;

public interface AuthorizationHandler {
	boolean grantRole(User user, String role);
	boolean revokeRole(User user, String role);
	boolean revokeAllRoles(User user);
	boolean checkPrivilegesOfUser(User user, String path, String privilege, String policyName);
}
