package com.locus.auth;

import com.locus.auth.users.User;

public interface AuthenticationValidator {
	boolean checkPrivilegesOfUser(User user, String path, String privilege, String policyName);
}
