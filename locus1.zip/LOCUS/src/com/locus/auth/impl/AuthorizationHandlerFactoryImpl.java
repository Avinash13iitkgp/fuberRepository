package com.locus.auth.impl;

import com.locus.auth.AccessProvider;
import com.locus.auth.AuthenticationValidator;
import com.locus.auth.AuthorizationHandler;
import com.locus.auth.AuthorizationHandlerFactory;

public class AuthorizationHandlerFactoryImpl implements AuthorizationHandlerFactory {
	
	@Override
	public AuthorizationHandler getAuthorizationHandler(String type) {
		if(type==null || "".equalsIgnoreCase(type)){
			return null;
		}
		AuthorizationHandler authorizationHandler=null;
		AccessProvider accessProvider=null;
		AuthenticationValidator authenticationValidator=null;
		switch(type){
			case "locus":				
				accessProvider=LocusAccessProviderImpl.getInstance();
				authenticationValidator=LocusAuthenticationValidatorImpl.getInstance();
				authorizationHandler=new LocusAuthorizationHandlerImpl(accessProvider,authenticationValidator);						
			default:
		}
		return authorizationHandler;
	}

	
	

}
