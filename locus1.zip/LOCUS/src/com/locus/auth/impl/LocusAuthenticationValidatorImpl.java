package com.locus.auth.impl;

import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.locks.ReentrantLock;

import com.locus.auth.AuthenticationValidator;
import com.locus.auth.chain.responsibility.ChainDispenserFactory;
import com.locus.auth.chain.responsibility.PolicyChainOfResponsibility;
import com.locus.auth.users.Role;
import com.locus.auth.users.User;
import com.locus.policy.loader.PolicyClassLoader;
import com.locus.policy.loader.PolicyMO;
import com.locus.policy.loader.RolesMO;
import com.locus.resources.loader.ResourceClassLoader;
import com.locus.resources.loader.ResourceMO;

// TODO - Use chain of responsibility principle.
public class LocusAuthenticationValidatorImpl implements AuthenticationValidator{
	private static LocusAuthenticationValidatorImpl instance;
	private static final ReentrantLock lock = new ReentrantLock();

	private LocusAuthenticationValidatorImpl(){
	}
	
	public static LocusAuthenticationValidatorImpl getInstance(){
		 if (null == instance) {
	        lock.lock();
	        try {
	            if (null == instance) {
	            	instance = new LocusAuthenticationValidatorImpl();
	            	}
	            } finally {
	                lock.unlock();
	            }
	      }
	        return instance;
	}

	
	ResourceMO resourceMO=ResourceClassLoader.getResourceMO();
	PolicyMO policyMO=PolicyClassLoader.getPolicyMO();
	
	@Override
	public boolean checkPrivilegesOfUser(User user, String path, String privilege,String policyName) {
		if(user==null){
			return false;
		}
		if(path==null || "".equalsIgnoreCase(path)){
			return false;
		}
		Set<Role>roles= user.getRoles();
		if(roles==null || roles.size()==0){  
			return false;
		}
		Iterator<Role> it = roles.iterator();
		PolicyChainOfResponsibility head = new ChainDispenserFactory().getChainHead("locus");
		while(it.hasNext()){
			Role role = it.next();
			String roleName=role.getRoleName();
			if(policyMO.getPolicy()!=null && policyMO.getPolicy().size()>0){
				for(int i=0;i<policyMO.getPolicy().size();i++){
					Map<String, RolesMO> policy = policyMO.getPolicy().get(i);
					if(policy.containsKey(roleName)){
						RolesMO specificPolicy = policy.get(roleName);
							boolean check=head.check(role, path, privilege, specificPolicy, null);
							if(check){
								return true;
							}
						}
						
					}
				}
			}
		return false;
	}	
}
