package com.locus.auth.impl;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.locks.ReentrantLock;

import com.locus.auth.AccessProvider;
import com.locus.auth.users.Role;
import com.locus.auth.users.User;
import com.locus.auth.users.impl.LocusRoleImpl;

public class LocusAccessProviderImpl implements AccessProvider {
	private static volatile LocusAccessProviderImpl instance=null;
	
	private static final ReentrantLock lock = new ReentrantLock();

	private LocusAccessProviderImpl(){
	}
	
	public static LocusAccessProviderImpl getInstance(){
		 if (null == instance) {
	        lock.lock();
	        try {
	            if (null == instance) {
	            	instance = new LocusAccessProviderImpl();
	            	}
	            } finally {
	                lock.unlock();
	            }
	      }
	        return instance;
	}
	
	@Override
	public boolean revokeRole(User user, String role) {
		if(user==null || user.getRoles()==null || user.getRoles().size()==0){
			return false;
		}
		if(role==null || "".equalsIgnoreCase(role)){
			return false;
		}
		Set<Role> roles = user.getRoles();
		Iterator<Role> it = roles.iterator();
		while(it.hasNext()){
			Role roleEach = it.next();
			if(roleEach.getRoleName()!=null && role.equalsIgnoreCase(roleEach.getRoleName())){
				it.remove();
				return true;
			}
		}
		return false;
		
	}

	// TODO - See if throwing Exception makes sense instead of returning boolean.
	// TODO - What if grantRole is invoked for already assigned role.
	@Override
	public boolean grantRole(User user, String role) {
		if(user==null)
		{
			return false;
		}
		
		if(user.getRoles()==null){
			Set<Role> roles=new HashSet<Role>();
			user.setRoles(roles);		
		}
		if(checkIfUserHasARole(user, role)){
			return false;  //TODO log that role already there
		}
		user.getRoles().add(getRoleFromRoleEnum(role));
		return true;
	}
	
	public boolean checkIfUserHasARole(User user,String role){
		if(user==null || user.getRoles()==null || role==null || "".equals(role)){
			return false;
		}
		Set<Role> roles = user.getRoles();		
		Iterator<Role> it=roles.iterator();
		Role r2=getRoleFromRoleEnum(role);
		while(it.hasNext()){
			Role r1=it.next();
			if(r1.equals(r2)){
				return true;
			}
		}
		return false;
	}

	private Role getRoleFromRoleEnum(String role) {
		LocusRoleImpl role1=null;
		if(RoleEnum.ADMIN.getRole().equals(role))
			{
				role1=new LocusRoleImpl();
				role1.setRoleName(role);
			}
		if(RoleEnum.EXTERNAL.getRole().equals(role)){
			role1=new LocusRoleImpl();
			role1.setRoleName(role);
		}
		if(RoleEnum.MONITOR.getRole().equals(role)){
			role1=new LocusRoleImpl();
			role1.setRoleName(role);
		}
		return role1;
	}
	
}
