package com.locus.auth.impl;

import java.util.Iterator;

import com.locus.auth.AccessProvider;
import com.locus.auth.AuthenticationValidator;
import com.locus.auth.AuthorizationHandler;
import com.locus.auth.users.Role;
import com.locus.auth.users.User;

public class LocusAuthorizationHandlerImpl implements AuthorizationHandler {

	private AccessProvider accessProvider;
	private AuthenticationValidator authenticationValidator;
	
	protected LocusAuthorizationHandlerImpl(AccessProvider accessProvider,AuthenticationValidator authenticationValidator) {
		this.accessProvider=accessProvider;
		this.authenticationValidator=authenticationValidator;
	}

	@Override
	public boolean checkPrivilegesOfUser(User user, String path, String privilege,String policyName) {
		return authenticationValidator.checkPrivilegesOfUser(user, path, privilege,policyName);
	}
	@Override
	public boolean grantRole(User user,String role) {
		return accessProvider.grantRole(user,role);
	}
	@Override
	public boolean revokeRole(User user,String role) {
		return accessProvider.revokeRole(user, role);
	}
	// TODO - Call revokeRole from revokeAllRoles iterating over all the roles.
	@Override
	public boolean revokeAllRoles(User user) {
		if(user==null){
			return false;
		}
		if(user.getRoles()==null || user.getRoles().size()==0){
			return false;
		}
		Iterator<Role> it = user.getRoles().iterator();
		boolean flag=true;
		while(it.hasNext()){
			Role role = it.next();
			flag=flag && revokeRole(user, role.getRoleName());  //even if one fails we return false
		}
		return flag;
	}

}
